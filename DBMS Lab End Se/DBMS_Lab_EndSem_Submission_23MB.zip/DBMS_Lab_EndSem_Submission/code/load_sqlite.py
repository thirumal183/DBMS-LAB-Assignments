"""Load the five supplied/cleaned telemetry extracts into a local SQLite DB."""
from pathlib import Path
import csv, sqlite3
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
DB = ROOT / 'dbms_telemetry.sqlite'
SCHEMA = {
 'player_profile': (['device_id','original_device_id','install_date','platform','country','country_tier','acquisition_channel','first_purchase_date'],
  'CREATE TABLE player_profile(device_id INTEGER, original_device_id INTEGER, install_date TEXT, platform TEXT, country TEXT, country_tier INTEGER, acquisition_channel TEXT, first_purchase_date TEXT)'),
 'player_day': (['device_id','activity_date','player_level','session_count','playtime_minutes','app_version'],
  'CREATE TABLE player_day(device_id INTEGER, activity_date INTEGER, player_level INTEGER, session_count INTEGER, playtime_minutes REAL, app_version TEXT)'),
 'purchase': (['purchase_id','device_id','event_date','event_time','pack_name','usd_amount','currency_granted','sale_flag'],
  'CREATE TABLE purchase(purchase_id TEXT, device_id INTEGER, event_date TEXT, event_time TEXT, pack_name TEXT, usd_amount REAL, currency_granted INTEGER, sale_flag INTEGER)'),
 'currency_spend': (['device_id','event_ts','spend_type','currency_type','currency_value','spend_category','player_level','premium_balance','social_balance','grind_balance'],
  'CREATE TABLE currency_spend(device_id INTEGER, event_ts TEXT, spend_type TEXT, currency_type TEXT, currency_value INTEGER, spend_category TEXT, player_level INTEGER, premium_balance INTEGER, social_balance INTEGER, grind_balance INTEGER)'),
 'ad_view': (['device_id','event_ts','status','placement','reward_type','reward_amount','ad_daily_count','ad_daily_cap'],
  'CREATE TABLE ad_view(device_id INTEGER, event_ts TEXT, status TEXT, placement TEXT, reward_type TEXT, reward_amount INTEGER, ad_daily_count INTEGER, ad_daily_cap INTEGER)')
}
if DB.exists(): DB.unlink()
con=sqlite3.connect(DB)
cur=con.cursor()
for table,(cols,ddl) in SCHEMA.items():
    cur.execute(ddl)
    placeholders=','.join(['?']*len(cols))
    batch=[]
    with (DATA/f'{table}.csv').open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f)
        for row in reader:
            batch.append(tuple(row[c] if row[c] != '' else None for c in cols))
            if len(batch)>=10000:
                cur.executemany(f'INSERT INTO {table} VALUES ({placeholders})',batch); batch=[]
        if batch: cur.executemany(f'INSERT INTO {table} VALUES ({placeholders})',batch)
    con.commit()
    print(f'{table}: {cur.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]:,} rows')
for idx in [
 'CREATE INDEX idx_player_day_device_date ON player_day(device_id, activity_date)',
 'CREATE INDEX idx_player_day_date ON player_day(activity_date)',
 'CREATE INDEX idx_purchase_device_date ON purchase(device_id, event_date)',
 'CREATE INDEX idx_purchase_date ON purchase(event_date)',
 'CREATE INDEX idx_ad_device_ts ON ad_view(device_id, event_ts)',
 'CREATE INDEX idx_ad_ts ON ad_view(event_ts)',
 'CREATE INDEX idx_currency_device_ts ON currency_spend(device_id, event_ts)']:
    cur.execute(idx)
con.commit(); con.close()
print(f'Created {DB}')
