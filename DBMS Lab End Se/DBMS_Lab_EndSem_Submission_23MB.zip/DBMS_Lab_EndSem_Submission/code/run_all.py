"""Rebuild all analysis outputs, model, charts and PowerPoint from data/*.csv."""
from pathlib import Path
import subprocess, sys, os
ROOT=Path(__file__).resolve().parent.parent
# Avoid BLAS thread oversubscription on machines with many reported CPU cores.
ENV=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    ENV[key] = '1'
for script in ['run_analysis.py','train_churn_model.py','build_charts.py','build_deck.py']:
    print(f'Running {script} ...', flush=True)
    subprocess.run([sys.executable, str(ROOT/'code'/script)], cwd=ROOT, check=True, env=ENV)
print('Finished. Open DBMS_Lab_EndSem_Readout.pptx.')
