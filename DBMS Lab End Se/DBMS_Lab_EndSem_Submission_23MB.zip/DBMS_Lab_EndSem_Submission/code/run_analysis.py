import pandas as pd, numpy as np, json, os
from scipy import stats
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
B=str(ROOT/'data'); O=str(ROOT/'results'); os.makedirs(O,exist_ok=True)
prof=pd.read_csv(B+'/player_profile.csv',parse_dates=['install_date','first_purchase_date'])
day=pd.read_csv(B+'/player_day.csv'); day['date']=pd.to_datetime(day.activity_date.astype(str),format='%Y%m%d')
pur=pd.read_csv(B+'/purchase.csv'); pur['date']=pd.to_datetime(pur.event_date); pur['ts']=pd.to_datetime(pur.event_date+' '+pur.event_time)
cur=pd.read_csv(B+'/currency_spend.csv'); cur['ts']=pd.to_datetime(cur.event_ts); cur['date']=cur.ts.dt.normalize()
ad=pd.read_csv(B+'/ad_view.csv'); ad['ts']=pd.to_datetime(ad.event_ts); ad['date']=ad.ts.dt.normalize()
# summary
summ={'profile_rows':len(prof),'unique_devices':prof.device_id.nunique(),'player_day_rows':len(day),'purchase_rows':len(pur),'currency_spend_rows':len(cur),'ad_rows':len(ad),'window_start':'2026-01-01','window_end':'2026-04-30'}
# linked id coverage
summ['linked_device_rows']=int(prof.original_device_id.notna().sum()); summ['linked_original_ids_present_in_profile']=int(prof.original_device_id.dropna().isin(prof.device_id).sum()); summ['canonical_duplicate_groups']=int(prof.assign(canon=prof.original_device_id.fillna(prof.device_id)).canon.duplicated().sum())
# data quality
summ['profile_install_outside_window']=int((~prof.install_date.between('2026-01-01','2026-04-30')).sum())
summ['profile_first_purchase_before_install']=int((prof.first_purchase_date<prof.install_date).sum())
summ['profile_first_purchase_no_purchase_event']=int((prof.first_purchase_date.notna() & ~prof.device_id.isin(pur.loc[pur.usd_amount>0,'device_id'])).sum())
summ['purchase_negative_rows']=int((pur.usd_amount<0).sum()); summ['purchase_duplicate_id_groups']=int(pur.purchase_id.duplicated(False).sum()/2); summ['purchase_rows_with_duplicate_id']=int(pur.purchase_id.duplicated(False).sum())
summ['purchase_negative_revenue']=float(pur.loc[pur.usd_amount<0,'usd_amount'].sum()); summ['purchase_positive_revenue']=float(pur.loc[pur.usd_amount>0,'usd_amount'].sum()); summ['purchase_signed_revenue']=float(pur.usd_amount.sum())
summ['ad_outside_window_rows']=int((~ad.date.between('2026-01-01','2026-04-30')).sum()); summ['ad_status_counts']=ad.status.value_counts().to_dict()
summ['day_duplicate_player_date']=int(day.duplicated(['device_id','date']).sum())
summ['currency_duplicate_device_timestamp']=int(cur.duplicated(['device_id','ts']).sum())
summ['currency_negative_value_rows']=int((cur.currency_value<0).sum()); summ['currency_zero_value_rows']=int((cur.currency_value==0).sum())
summ['currency_negative_balance_rows']=int(((cur[['premium_balance','social_balance','grind_balance']]<0).any(axis=1)).sum())
# Purchase events are not always paired with a player_day row on the same date.
positive_purchase_days=pur[pur.usd_amount>0][['device_id','date']].drop_duplicates()
active_day_keys=day[['device_id','date']].drop_duplicates()
nonactive_purchase_days=positive_purchase_days.merge(active_day_keys,on=['device_id','date'],how='left',indicator=True).query('_merge=="left_only"')
summ['positive_purchase_player_days_without_activity_row']=int(len(nonactive_purchase_days))
summ['players_with_purchase_without_same_day_activity_row']=int(nonactive_purchase_days.device_id.nunique())
# install volumes
inst=prof[prof.install_date.between('2026-01-01','2026-04-30')].groupby(prof.install_date.dt.to_period('W').astype(str)).size().rename('installs').reset_index(name='installs')
inst.to_csv(O+'/install_volume_by_week.csv',index=False)
# daily health by platform
active=day.merge(prof[['device_id','platform']],on='device_id',how='left',validate='many_to_one')
dau=active.groupby(['date','platform']).device_id.nunique().rename('dau')
rev=pur[pur.date.between('2026-01-01','2026-04-30')].merge(prof[['device_id','platform']],on='device_id',how='left')
rev['gross_revenue']=rev.usd_amount.clip(lower=0); rev['negative_adjustments']=rev.usd_amount.clip(upper=0)
revday=rev.groupby(['date','platform']).agg(gross_revenue=('gross_revenue','sum'),negative_adjustments=('negative_adjustments','sum'),net_revenue_signed=('usd_amount','sum'))
active_keys=active[['date','device_id','platform']].drop_duplicates()
active_purchases=rev[rev.usd_amount>0][['date','device_id','platform']].drop_duplicates().merge(active_keys,on=['date','device_id','platform'],how='inner')
payers=active_purchases.groupby(['date','platform']).device_id.nunique().rename('daily_payers')
health=pd.concat([dau,revday,payers],axis=1).fillna(0).reset_index(); health['arpdau']=health.gross_revenue/health.dau.replace(0,np.nan); health['payer_share_dau']=health.daily_payers/health.dau.replace(0,np.nan)
health.to_csv(O+'/daily_health_platform.csv',index=False)
# retention cohorts Jan-Apr, install week (Mon)
p=prof[prof.install_date.between('2026-01-01','2026-04-30')][['device_id','install_date','acquisition_channel','country_tier','platform']].copy()
p['cohort_week']=p.install_date.dt.to_period('W-SUN').apply(lambda x:x.start_time)
active_pairs=day[['device_id','date']].drop_duplicates().merge(p[['device_id','install_date','cohort_week']],on='device_id',how='inner')
active_pairs['age_day']=(active_pairs.date-active_pairs.install_date).dt.days
milestones=[1,7,14,30]
cohort_rows=[]
end=pd.Timestamp('2026-04-30')
for cw,g in p.groupby('cohort_week'):
 n=len(g)
 for m in milestones:
  eligible=g[g.install_date+pd.to_timedelta(m,unit='D')<=end]
  ids=set(eligible.device_id)
  active_ids=set(active_pairs.loc[(active_pairs.cohort_week==cw)&(active_pairs.age_day==m),'device_id'])
  cohort_rows.append({'cohort_week':cw.date().isoformat(),'milestone_day':m,'cohort_installs':n,'eligible_n':len(ids),'active_n':len(ids&active_ids),'retention':len(ids&active_ids)/len(ids) if len(ids) else np.nan})
ret=pd.DataFrame(cohort_rows); ret.to_csv(O+'/retention_cohorts_long.csv',index=False)
ret.pivot(index='cohort_week',columns='milestone_day',values='retention').to_csv(O+'/retention_cohorts_grid.csv')
# spender behaviour positive purchases only for purchase frequency / first purchase
pos=pur[pur.usd_amount>0].copy()
player_rev=pur.groupby('device_id').usd_amount.sum().rename('net_revenue')
player_pos=pos.groupby('device_id').agg(purchases=('purchase_id','size'),positive_revenue=('usd_amount','sum'))
payers_n=player_pos.shape[0]
rev_total=pur.usd_amount.sum(); gross_total=pos.usd_amount.sum()
conc=[]
# Rank payers by positive purchase revenue; report gross contribution and net sensitivity.
ranked=player_pos.positive_revenue.sort_values(ascending=False)
for pct in [.01,.10,.50]:
 n=int(np.ceil(payers_n*pct)); top_ids=ranked.head(n).index
 gross_share=ranked.head(n).sum()/gross_total
 net_share=player_rev.reindex(top_ids).fillna(0).sum()/rev_total
 conc.append({'population':'players with >=1 positive purchase; ranked by positive gross revenue','top_share':pct,'players':n,'payers':payers_n,'gross_revenue_share':gross_share,'net_revenue_share_same_payers':net_share})
pd.DataFrame(conc).to_csv(O+'/revenue_concentration.csv',index=False)
# first purchase based on profile field; invalid negative intervals flagged, include all player denominator
f=prof[['device_id','install_date','first_purchase_date']].copy(); f['days_to_first_purchase']=(f.first_purchase_date-f.install_date).dt.days
f.to_csv(O+'/first_purchase_by_player.csv',index=False)
valid=f[f.first_purchase_date.notna() & (f.days_to_first_purchase>=0)]
bins=[-1,0,1,3,7,14,30,60,90,100000]; labels=['0','1','2–3','4–7','8–14','15–30','31–60','61–90','90+']
valid=valid.copy(); valid['time_bin']=pd.cut(valid.days_to_first_purchase,bins=bins,labels=labels)
ttf=valid.time_bin.value_counts(sort=False).rename_axis('days_after_install').reset_index(name='players'); ttf['share_of_payers_valid']=ttf.players/len(valid); ttf['valid_payers']=len(valid); ttf['all_players']=len(prof); ttf['never_pay_share_profile']=prof.first_purchase_date.isna().mean(); ttf.to_csv(O+'/time_to_first_purchase_distribution.csv',index=False)
# repeat purchase gaps, positive purchase rows, preserve same id distinct event times
pos=pos.sort_values(['device_id','ts']); pos['prev_ts']=pos.groupby('device_id').ts.shift(); pos['gap_days']=(pos.ts-pos.prev_ts).dt.total_seconds()/86400
repeat=pos[pos.gap_days.notna()]
repeat_summary={'repeat_buyers':int(repeat.device_id.nunique()),'consecutive_gaps':len(repeat),'mean_gap_days':float(repeat.gap_days.mean()),'median_gap_days':float(repeat.gap_days.median()),'p25_gap_days':float(repeat.gap_days.quantile(.25)),'p75_gap_days':float(repeat.gap_days.quantile(.75))}
repeat.gap_days.describe(percentiles=[.1,.25,.5,.75,.9]).to_csv(O+'/repeat_purchase_gap_summary.csv')
# ads: player-day with completed views and cap based on max count from completed events
adwin=ad[ad.date.between('2026-01-01','2026-04-30')].copy()
completed=adwin[adwin.status=='completed']
for label,d in [('all_interactions',adwin),('completed_views',completed)]:
 daily=d.groupby('date').size().rename(label)
 daily.to_csv(O+f'/daily_{label}.csv')
# player-days with any completed event; max daily count and cap; inconsistent cap by day check
# A player-day hits cap if any completed event records count >= that event's cap.
# Classify the day by the cap attached to its peak-count completed event.
completed=completed.copy(); completed['event_hit_cap']=completed.ad_daily_count>=completed.ad_daily_cap
peak_idx=completed.groupby(['device_id','date']).ad_daily_count.idxmax()
peak=completed.loc[peak_idx,['device_id','date','ad_daily_count','ad_daily_cap']].rename(columns={'ad_daily_count':'peak_count','ad_daily_cap':'cap_at_peak'})
adpd=completed.groupby(['device_id','date']).agg(hit_cap=('event_hit_cap','any'),cap_values=('ad_daily_cap','nunique'),events=('status','size'),reward_total=('reward_amount','sum')).reset_index().merge(peak,on=['device_id','date'],how='left')
capstats=adpd.groupby('cap_at_peak').agg(player_days=('device_id','size'),hit_cap_days=('hit_cap','sum'),share_hit_cap=('hit_cap','mean'),avg_peak_count=('peak_count','mean')).reset_index().rename(columns={'cap_at_peak':'cap'}); capstats.to_csv(O+'/ad_cap_by_player_day.csv',index=False)
summ['ad_player_days_completed']=len(adpd); summ['ad_player_days_cap_inconsistent']=int((adpd.cap_values>1).sum()); summ['ad_daily_rows_outside_window']=summ['ad_outside_window_rows']
# Full 120-day calendar: retain NULL on dates with no event rows rather than inventing a zero.
ad_daily=pd.DataFrame({'all_interactions':adwin.groupby('date').size(),'completed':completed.groupby('date').size(),'abandoned':adwin[adwin.status=='abandoned'].groupby('date').size(),'started':adwin[adwin.status=='started'].groupby('date').size()})
calendar=pd.date_range('2026-01-01','2026-04-30',freq='D'); ad_daily=ad_daily.reindex(calendar); ad_daily.index.name='date'
ad_daily['dau']=day.groupby('date').device_id.nunique().reindex(calendar)
ad_daily['views_per_dau']=ad_daily.all_interactions/ad_daily.dau
ad_daily.to_csv(O+'/daily_ad_views.csv')
summ['ad_missing_days_in_window']=int(ad_daily.all_interactions.isna().sum())
# deep dive ARPDAU first vs last 30 days
periods={'first30':('2026-01-01','2026-01-30'),'last30':('2026-04-01','2026-04-30')}
# merge tier to activity, purchase
acttier=day.merge(prof[['device_id','country_tier']],on='device_id',how='left')
revtier=pur.merge(prof[['device_id','country_tier']],on='device_id',how='left')
tierrows=[]
for pn,(s,e) in periods.items():
 aa=acttier[acttier.date.between(s,e)].groupby('country_tier').device_id.nunique() # unique in period, but ARPDAU denom should sum daily actives
 aa=acttier[acttier.date.between(s,e)].groupby('country_tier').size().rename('active_player_days')
 rr=revtier[revtier.date.between(s,e)].assign(gross=revtier.loc[revtier.date.between(s,e),'usd_amount'].clip(lower=0)).groupby('country_tier').gross.sum().rename('revenue')
 dd=pd.concat([aa,rr],axis=1).fillna(0); dd['arpdau']=dd.revenue/dd.active_player_days; dd['dau_mix']=dd.active_player_days/dd.active_player_days.sum(); dd['period']=pn
 tierrows.append(dd.reset_index())
tier=pd.concat(tierrows); tier.to_csv(O+'/tier_arpdau_period.csv',index=False)
# total period weighted arpdau
allrows=[]
for pn,(s,e) in periods.items():
 a=acttier[acttier.date.between(s,e)].shape[0]; r=revtier.loc[revtier.date.between(s,e),'usd_amount'].clip(lower=0).sum(); allrows.append({'period':pn,'active_player_days':a,'revenue':r,'arpdau':r/a})
pd.DataFrame(allrows).to_csv(O+'/overall_arpdau_period.csv',index=False)
# decomposition with first-period mix weights applied to last tier rates
wide=tier.pivot(index='country_tier',columns='period',values=['arpdau','dau_mix'])
std_first_mix=(wide['arpdau']['last30']*wide['dau_mix']['first30']).sum()
std_last_mix=(wide['arpdau']['last30']*wide['dau_mix']['last30']).sum()
base_first_mix=(wide['arpdau']['first30']*wide['dau_mix']['first30']).sum()
# acquisition mix changes
# Part 3 30-day outcomes for installs Jan1-Mar31 to ensure complete window
eligible=prof[prof.install_date.between('2026-01-01','2026-03-31')].copy()
newinst=prof[prof.install_date.between('2026-01-01','2026-04-30')].copy(); newinst['install_month']=newinst.install_date.dt.to_period('M').astype(str)
pd.crosstab(newinst.install_month,newinst.acquisition_channel).to_csv(O+'/install_month_by_channel.csv')
pd.crosstab(newinst.acquisition_channel,newinst.country_tier,normalize='index').to_csv(O+'/channel_country_tier_mix.csv')
pd.crosstab(newinst.install_month,newinst.country_tier,normalize='index').to_csv(O+'/install_month_country_tier_mix.csv')
enddates=eligible[['device_id','install_date','acquisition_channel','country_tier','platform']].copy(); enddates['end30']=enddates.install_date+pd.Timedelta(days=30)
# activity 0..29 days after install (30 days incl install day)
a30=day.merge(enddates[['device_id','install_date','end30']],on='device_id',how='inner')
a30=a30[(a30.date>=a30.install_date)&(a30.date<a30.end30)]
a30m=a30.groupby('device_id').agg(active_days_30=('date','nunique'),sessions_30=('session_count','sum'),playtime_30=('playtime_minutes','sum'),max_level_30=('player_level','max')).reset_index()
# revenue in 30d, signed and positive
p30=pur.merge(enddates[['device_id','install_date','end30']],on='device_id',how='inner')
p30=p30[(p30.ts>=p30.install_date)&(p30.ts<p30.end30)]
p30m=p30.groupby('device_id').agg(revenue_30=('usd_amount',lambda s:s[s>0].sum()),net_revenue_30=('usd_amount','sum'),purchases_30=('usd_amount',lambda s:(s>0).sum()),sale_purchases_30=('sale_flag','sum')).reset_index()
co=enddates.merge(a30m,on='device_id',how='left').merge(p30m,on='device_id',how='left').fillna({'active_days_30':0,'sessions_30':0,'playtime_30':0,'max_level_30':0,'revenue_30':0,'net_revenue_30':0,'purchases_30':0,'sale_purchases_30':0})
co['retained_d7']=co.device_id.isin(set(a30.loc[(a30.date-a30.install_date).dt.days==7,'device_id']))
co['payer_30']=(co.purchases_30>0).astype(int)
co.to_csv(O+'/channel_player_30d.csv',index=False)
ch=co.groupby('acquisition_channel').agg(players=('device_id','size'),avg_active_days_30=('active_days_30','mean'),avg_playtime_30=('playtime_30','mean'),payer_rate_30=('payer_30','mean'),revenue_per_install_30=('revenue_30','mean'),net_revenue_per_install_30=('net_revenue_30','mean'),avg_revenue_per_payer_30=('revenue_30',lambda s:s[s>0].mean() if (s>0).any() else np.nan),d7_retention=('retained_d7','mean')).reset_index()
ch.to_csv(O+'/channel_30d_raw.csv',index=False)
# bootstrap diff channels vs organic on active days and revenue/install, with fixed seed
rng=np.random.default_rng(20261124)
boot=[]
for metric in ['active_days_30','revenue_30','net_revenue_30','payer_30']:
 org=co.loc[co.acquisition_channel=='organic',metric].to_numpy()
 for channel in ['paid_social','paid_video']:
  vals=co.loc[co.acquisition_channel==channel,metric].to_numpy()
  reps=[]
  for _ in range(2000): reps.append(rng.choice(vals,len(vals),replace=True).mean()-rng.choice(org,len(org),replace=True).mean())
  obs=vals.mean()-org.mean(); lo,hi=np.quantile(reps,[.025,.975]); boot.append({'metric':metric,'comparison':f'{channel} - organic','difference':obs,'ci_low':lo,'ci_high':hi,'p_boot_two_sided':min(1,2*min((np.array(reps)<=0).mean(),(np.array(reps)>=0).mean()))})
pd.DataFrame(boot).to_csv(O+'/channel_bootstrap_ci.csv',index=False)
# adjusted regression via statsmodels; robust HC3
import statsmodels.formula.api as smf
co['install_week']=co.install_date.dt.to_period('W-SUN').astype(str)
reg=[]
for metric in ['active_days_30','revenue_30','payer_30']:
 model=smf.ols(f'{metric} ~ C(acquisition_channel, Treatment(reference="organic")) + C(country_tier) + C(platform) + C(install_week)',data=co).fit(cov_type='HC3')
 for term in model.params.index:
  if 'acquisition_channel' in term:
   reg.append({'metric':metric,'term':term,'coef':model.params[term],'se':model.bse[term],'ci_low':model.conf_int().loc[term,0],'ci_high':model.conf_int().loc[term,1],'p_value':model.pvalues[term]})
pd.DataFrame(reg).to_csv(O+'/channel_adjusted_regression.csv',index=False)
# churn panel snapshots
# weekly snapshot dates; active if any player_day in previous 7 days, matured install >=14d
snapshots=pd.date_range('2026-01-22','2026-04-16',freq='7D')
# Use daily aggregations for features; event tables within windows
churn_rows=[]
for snap in snapshots:
    prior_start=snap-pd.Timedelta(days=14); prior7=snap-pd.Timedelta(days=7); future_end=snap+pd.Timedelta(days=14)
    # eligible active within last 7 days and install age >=14
    elig=prof[(prof.install_date<=prior7)&(prof.install_date<=snap-pd.Timedelta(days=14))][['device_id','install_date','platform','country_tier','acquisition_channel']]
    hist=day[(day.date>=prior7)&(day.date<snap)]
    activeids=set(hist.device_id)
    elig=elig[elig.device_id.isin(activeids)].copy()
    if elig.empty: continue
    h30=day[(day.date>=snap-pd.Timedelta(days=30))&(day.date<snap)&day.device_id.isin(elig.device_id)]
    h14=day[(day.date>=prior_start)&(day.date<snap)&day.device_id.isin(elig.device_id)]
    h7=day[(day.date>=prior7)&(day.date<snap)&day.device_id.isin(elig.device_id)]
    f=elig.set_index('device_id')
    for name,df in [('7',h7),('14',h14),('30',h30)]:
        g=df.groupby('device_id').agg(**{f'active_days_{name}':('date','nunique'),f'sessions_{name}':('session_count','sum'),f'playtime_{name}':('playtime_minutes','sum'),f'max_level_{name}':('player_level','max')})
        f=f.join(g,how='left')
    # recency from last activity date pre snapshot
    last=day[(day.date<snap)&day.device_id.isin(elig.device_id)].groupby('device_id').date.max()
    f['recency_days']=(snap-last).dt.days
    # purchase and ad features from prior 30 days
    ph=pur[(pur.ts>=snap-pd.Timedelta(days=30))&(pur.ts<snap)&pur.device_id.isin(elig.device_id)]
    pg=ph.groupby('device_id').agg(purchases_30=('usd_amount',lambda s:(s>0).sum()),revenue_30=('usd_amount','sum'),last_purchase=('ts','max'))
    f=f.join(pg,how='left'); f['days_since_purchase']=(snap-f.last_purchase).dt.days; f=f.drop(columns=['last_purchase'])
    ah=ad[(ad.ts>=snap-pd.Timedelta(days=30))&(ad.ts<snap)&ad.device_id.isin(elig.device_id)]
    ag=ah.groupby('device_id').agg(ad_completions_30=('status',lambda s:(s=='completed').sum()),ad_abandons_30=('status',lambda s:(s=='abandoned').sum()))
    f=f.join(ag,how='left')
    # Currency-spend behaviour in the preceding 30 days.
    sh=cur[(cur.ts>=snap-pd.Timedelta(days=30))&(cur.ts<snap)&cur.device_id.isin(elig.device_id)].copy()
    sh['premium_value']=np.where(sh.currency_type=='PREMIUM',sh.currency_value,0)
    sh['paid_origin_event']=(sh.spend_type=='paid').astype(int)
    sh['free_origin_event']=(sh.spend_type=='free').astype(int)
    sh['subscription_origin_event']=(sh.spend_type=='subscription').astype(int)
    sg=sh.groupby('device_id').agg(currency_spend_events_30=('currency_value','size'),currency_value_spent_30=('currency_value','sum'),premium_value_spent_30=('premium_value','sum'),paid_origin_spend_events_30=('paid_origin_event','sum'),free_origin_spend_events_30=('free_origin_event','sum'),subscription_origin_spend_events_30=('subscription_origin_event','sum'))
    f=f.join(sg,how='left')
    # Label: no active day from snap inclusive to snap+14 exclusive
    future=day[(day.date>=snap)&(day.date<future_end)]
    future_ids=set(future.device_id)
    f['churned_14d']=(~f.index.isin(future_ids)).astype(int)
    f['snapshot_date']=snap
    f=f.reset_index().rename(columns={'index':'device_id'})
    churn_rows.append(f)
churn=pd.concat(churn_rows,ignore_index=True)
# fill missing counts, feature recency; add categorical encoded later
for c in churn.columns:
 if c.startswith(('active_days_','sessions_','playtime_','max_level_','purchases_','revenue_','ad_','currency_','premium_value_','paid_origin_','free_origin_','subscription_origin_')): churn[c]=churn[c].fillna(0)
churn['days_since_purchase']=churn.days_since_purchase.fillna(45).clip(0,45)
churn.to_csv(O+'/churn_training_panel.csv',index=False)
summ['churn_panel_rows']=len(churn); summ['churn_snapshots']=len(snapshots); summ['churn_rate']=float(churn.churned_14d.mean())
# Save summary and core stats
summ.update({'payers':payers_n,'repeat_summary':repeat_summary,'arpdau_decomposition':{'last30_rates_at_first30_mix':float(std_first_mix),'last30_rates_at_last30_mix':float(std_last_mix),'first30_rates_at_first30_mix':float(base_first_mix),'mix_effect_vs_fixed_first':float(std_last_mix-std_first_mix),'within_tier_effect':float(std_first_mix-base_first_mix)}})
with open(O+'/data_quality_summary.json','w') as f: json.dump(summ,f,indent=2,default=str)
print(json.dumps(summ,indent=2,default=str))
print('\nINSTALLS\n',inst.to_string(index=False))
print('\nHEALTH SAMPLE\n',health.head().to_string(index=False))
print('\nTIER\n',tier.to_string(index=False))
print('\nOVERALL\n',pd.DataFrame(allrows).to_string(index=False))
print('\nRETENTION\n',ret.pivot(index='cohort_week',columns='milestone_day',values='retention').round(3).to_string())
print('\nCONCENTRATION\n',pd.DataFrame(conc).to_string(index=False))
print('\nTTFP\n',ttf.to_string(index=False))
print('\nAD CAP\n',capstats.to_string(index=False))
print('\nCHANNEL\n',ch.to_string(index=False))
print('\nBOOT\n',pd.DataFrame(boot).to_string(index=False))
print('\nREG\n',pd.DataFrame(reg).to_string(index=False))
print('\nCHURN rows/rate',len(churn),churn.churned_14d.mean())
