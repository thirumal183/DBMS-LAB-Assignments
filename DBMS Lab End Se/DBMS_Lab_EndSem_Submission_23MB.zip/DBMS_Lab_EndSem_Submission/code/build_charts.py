from pathlib import Path
import pandas as pd, numpy as np, matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent.parent; R=ROOT/'results'; C=ROOT/'charts'; C.mkdir(exist_ok=True)
# 1 Monthly install mix
m=pd.read_csv(R/'install_month_by_channel.csv').set_index('install_month')
fig,ax=plt.subplots(figsize=(10,5.3)); m.plot(kind='bar',stacked=True,ax=ax,width=.65)
ax.set_title('New installs accelerated as paid video expanded',loc='left',weight='bold',fontsize=15)
ax.set_xlabel('Install month');ax.set_ylabel('New installs');ax.legend(title='Acquisition channel',frameon=False,ncol=3,loc='upper left')
for i,total in enumerate(m.sum(axis=1)):
 ax.text(i,total+350,f'{int(total):,}',ha='center',fontsize=9)
ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(C/'install_mix.png',dpi=180);plt.close(fig)
# 2 ARPDAU by tier
x=pd.read_csv(R/'tier_arpdau_period.csv'); piv=x.pivot(index='country_tier',columns='period',values='arpdau')
fig,ax=plt.subplots(figsize=(8.5,4.8));piv.plot(kind='bar',ax=ax,width=.7)
ax.set_title('Every country tier monetised better in April',loc='left',weight='bold',fontsize=14)
ax.set_xlabel('Country tier (1 = highest revenue potential)');ax.set_ylabel('ARPDAU (USD)');ax.legend(title='Period',frameon=False)
ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(C/'tier_arpdau.png',dpi=180);plt.close(fig)
# 3 DAU mix shift
mix=x.pivot(index='period',columns='country_tier',values='dau_mix').reindex(['first30','last30'])
fig,ax=plt.subplots(figsize=(8.5,4.8));mix.plot(kind='bar',stacked=True,ax=ax,width=.6)
ax.set_title('The active audience shifted sharply toward Tier 4',loc='left',weight='bold',fontsize=14)
ax.set_xlabel('Period');ax.set_ylabel('Share of active player-days');ax.legend(title='Country tier',frameon=False,ncol=4,loc='upper center')
ax.set_xticklabels(['Jan 1–30','Apr 1–30'],rotation=0);ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(C/'tier_mix.png',dpi=180);plt.close(fig)
# 4 Channel adjusted effects forest panels
reg=pd.read_csv(R/'channel_adjusted_regression.csv')
fig,axs=plt.subplots(1,2,figsize=(11,4.7))
for ax,metric,title in [(axs[0],'active_days_30','Adjusted 30-day active days'),(axs[1],'revenue_30','Adjusted 30-day gross revenue / install')]:
 d=reg[reg.metric==metric].copy(); labels=['Paid social − organic','Paid video − organic']; d=d.set_index('term').reindex([d.term.iloc[0],d.term.iloc[1]])
 y=np.arange(len(d)); ax.errorbar(d.coef,y,xerr=[d.coef-d.ci_low,d.ci_high-d.coef],fmt='o',capsize=4)
 ax.axvline(0,linestyle='--',linewidth=1);ax.set_yticks(y,labels);ax.set_title(title,loc='left',weight='bold',fontsize=12);ax.set_xlabel('Difference (95% CI)');ax.spines[['top','right']].set_visible(False)
fig.suptitle('After controlling for tier, platform and install week',x=.03,ha='left',weight='bold',fontsize=14);fig.tight_layout();fig.savefig(C/'channel_adjusted.png',dpi=180);plt.close(fig)
# 5 retention heatmap
ret=pd.read_csv(R/'retention_cohorts_grid.csv',index_col=0)
fig,ax=plt.subplots(figsize=(9,6));arr=ret.to_numpy(dtype=float)
im=ax.imshow(arr,aspect='auto',vmin=0,vmax=.5)
ax.set_xticks(np.arange(len(ret.columns)),[f'Day {int(c)}' for c in ret.columns]);ax.set_yticks(np.arange(len(ret.index)),ret.index)
ax.set_title('Retention by install week (right-censored cells blank)',loc='left',weight='bold',fontsize=14)
for i in range(arr.shape[0]):
 for j in range(arr.shape[1]):
  if np.isfinite(arr[i,j]): ax.text(j,i,f'{arr[i,j]:.0%}',ha='center',va='center',fontsize=8)
fig.colorbar(im,ax=ax,label='Retention');ax.set_xlabel('Exact day after install');ax.set_ylabel('Install week (Monday)');fig.tight_layout();fig.savefig(C/'retention_heatmap.png',dpi=180);plt.close(fig)
# 6 daily ads
ad=pd.read_csv(R/'daily_ad_views.csv',parse_dates=['date'])
fig,axs=plt.subplots(2,1,figsize=(10,6.5),sharex=True)
axs[0].plot(ad.date,ad.all_interactions,label='All ad interactions');axs[0].plot(ad.date,ad.completed,label='Completed views');axs[0].set_ylabel('Daily events');axs[0].set_title('Daily rewarded-ad events rise with audience scale',loc='left',weight='bold',fontsize=14);axs[0].legend(frameon=False,ncol=2)
axs[1].plot(ad.date,ad.views_per_dau,label='Interactions per DAU');axs[1].set_ylabel('Interactions / DAU');axs[1].set_xlabel('Date');axs[1].legend(frameon=False)
missing=ad[ad.all_interactions.isna()]
for ax in axs:
 for d in missing.date: ax.axvline(d,linestyle=':',linewidth=1)
 ax.spines[['top','right']].set_visible(False)
fig.tight_layout();fig.savefig(C/'daily_ads.png',dpi=180);plt.close(fig)
# 7 churn top-decile targeting
th=pd.read_csv(R/'churn_thresholds.csv');th=th[th.target_fraction.astype(str).str.replace('.','',regex=False).str.isnumeric()].copy();th['target_fraction']=th.target_fraction.astype(float)
fig,ax=plt.subplots(figsize=(8.5,4.8));ax.plot(th.target_fraction*100,th.precision_churn*100,marker='o',label='Precision (share who churn)');ax.plot(th.target_fraction*100,th.recall_churn*100,marker='o',label='Recall (churners captured)');ax.axhline(23.2795,linestyle='--',label='Overall churn rate')
ax.set_xlabel('Share of active players targeted (highest risk first)');ax.set_ylabel('Percent');ax.set_title('Risk ranking concentrates churners, but wastes many offers',loc='left',weight='bold',fontsize=14);ax.legend(frameon=False);ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(C/'churn_targeting.png',dpi=180);plt.close(fig)
# 8 daily ARPDAU by platform
h=pd.read_csv(R/'daily_health_platform.csv',parse_dates=['date'])
fig,ax=plt.subplots(figsize=(10,4.8))
for plat,g in h.groupby('platform'):
 ax.plot(g.date,g.arpdau,label=plat,alpha=.85,linewidth=1.3)
ax.set_title('Daily ARPDAU by platform',loc='left',weight='bold',fontsize=14);ax.set_ylabel('USD per DAU');ax.set_xlabel('Date');ax.legend(frameon=False);ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(C/'daily_arpdau_platform.png',dpi=180);plt.close(fig)
# 9 concentration
conc=pd.read_csv(R/'revenue_concentration.csv')
fig,ax=plt.subplots(figsize=(7.5,4.5));ax.bar(['Top 1%','Top 10%','Top 50%'],conc.gross_revenue_share*100)
ax.set_ylabel('Share of positive gross revenue (%)');ax.set_title('Gross revenue concentration among 11,054 payers',loc='left',weight='bold',fontsize=14)
for i,v in enumerate(conc.gross_revenue_share*100):ax.text(i,v+1,f'{v:.1f}%',ha='center',fontsize=10)
ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(C/'revenue_concentration.png',dpi=180);plt.close(fig)
print('Charts written:',len(list(C.glob('*.png'))))
