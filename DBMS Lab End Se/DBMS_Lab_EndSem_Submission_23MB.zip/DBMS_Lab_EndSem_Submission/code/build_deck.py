from pathlib import Path
import json, pandas as pd, numpy as np
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.dml import MSO_THEME_COLOR
ROOT=Path(__file__).resolve().parent.parent; R=ROOT/'results'; C=ROOT/'charts'; OUT=ROOT/'DBMS_Lab_EndSem_Readout.pptx'
prs=Presentation(); prs.slide_width=Inches(13.333); prs.slide_height=Inches(7.5)
BLANK=prs.slide_layouts[6]
NAVY=RGBColor(19,42,64); BLUE=RGBColor(41,101,143); TEAL=RGBColor(31,125,137); GREY=RGBColor(91,105,117); LIGHT=RGBColor(238,243,247); WHITE=RGBColor(255,255,255); BLACK=RGBColor(28,36,44); PALE=RGBColor(247,249,251)

def textbox(slide,x,y,w,h,text,size=14,color=BLACK,bold=False,font='Aptos',align=None,margin=.04):
    sh=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h)); tf=sh.text_frame; tf.clear(); tf.word_wrap=True
    tf.margin_left=Inches(margin);tf.margin_right=Inches(margin);tf.margin_top=Inches(margin);tf.margin_bottom=Inches(margin)
    p=tf.paragraphs[0];p.text=str(text);p.font.name=font;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=color
    if align is not None:p.alignment=align
    return sh

def header(slide, section, title, subtitle=None, num=None):
    textbox(slide,.55,.24,4,.25,section.upper(),9,TEAL,True)
    textbox(slide,.55,.58,12.2,.5,title,24,NAVY,True)
    if subtitle: textbox(slide,.58,1.12,12.1,.38,subtitle,11,GREY)
    line=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(.55), Inches(1.55), Inches(12.2), Inches(.018)); line.fill.solid();line.fill.fore_color.rgb=LIGHT;line.line.fill.background()
    if num is not None: footer(slide,num)

def footer(slide,num):
    textbox(slide,.55,7.16,11,.18,'NIT WARANGAL  |  DBMS LAB  |  THIRUMAL  ·  24MAB0A25',8,GREY)
    textbox(slide,12.15,7.13,.55,.2,f'{num:02d}',8,GREY,align=PP_ALIGN.RIGHT)

def bullet_list(slide,x,y,w,items,size=14,spacing=.55,color=BLACK):
    for i,item in enumerate(items):
        textbox(slide,x,y+i*spacing,.22,.32,'•',size+2,TEAL,True)
        textbox(slide,x+.28,y+i*spacing,w-.28,spacing-.03,item,size,color)

def image(slide,path,x,y,w,h):
    slide.shapes.add_picture(str(path), Inches(x), Inches(y), width=Inches(w), height=Inches(h))

def table(slide,x,y,w,h,headers,rows,widths=None,font_size=10):
    sh=slide.shapes.add_table(len(rows)+1,len(headers),Inches(x),Inches(y),Inches(w),Inches(h));tb=sh.table
    if widths:
        for c,ww in enumerate(widths):tb.columns[c].width=Inches(ww)
    for r,row in enumerate([headers]+rows):
        for c,val in enumerate(row):
            cell=tb.cell(r,c);cell.text=str(val);cell.margin_left=Inches(.07);cell.margin_right=Inches(.07);cell.margin_top=Inches(.04);cell.margin_bottom=Inches(.03)
            cell.vertical_anchor=MSO_ANCHOR.MIDDLE
            cell.fill.solid();cell.fill.fore_color.rgb=NAVY if r==0 else (PALE if r%2 else WHITE)
            for p in cell.text_frame.paragraphs:
                p.font.name='Aptos';p.font.size=Pt(font_size if r else font_size);p.font.bold=(r==0);p.font.color.rgb=WHITE if r==0 else BLACK
    return sh

def note(slide,x,y,w,h,text,size=11):
    textbox(slide,x,y,w,h,text,size,GREY)

# read datasets
summary=json.load(open(R/'data_quality_summary.json'))
over=pd.read_csv(R/'overall_arpdau_period.csv').set_index('period')
tier=pd.read_csv(R/'tier_arpdau_period.csv')
channel=pd.read_csv(R/'channel_30d_raw.csv').set_index('acquisition_channel')
reg=pd.read_csv(R/'channel_adjusted_regression.csv')
ret=pd.read_csv(R/'retention_cohorts_long.csv')
conc=pd.read_csv(R/'revenue_concentration.csv')
ttf=pd.read_csv(R/'time_to_first_purchase_distribution.csv')
cap=pd.read_csv(R/'ad_cap_by_player_day.csv')
churn=json.load(open(R/'churn_model_summary.json'))
threshold=pd.read_csv(R/'churn_thresholds.csv'); threshold['target_fraction_num']=pd.to_numeric(threshold['target_fraction'],errors='coerce')

# 1 Title / academic cover (counts as the first of the maximum 8 readout slides)
s=prs.slides.add_slide(BLANK);s.background.fill.solid();s.background.fill.fore_color.rgb=NAVY
ACCENT=RGBColor(128,203,210); MUTED=RGBColor(190,208,220)
textbox(s,.75,.48,8.8,.30,'NATIONAL INSTITUTE OF TECHNOLOGY WARANGAL',11,ACCENT,True)
rule=s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(.78), Inches(.94), Inches(1.05), Inches(.045));rule.fill.solid();rule.fill.fore_color.rgb=TEAL;rule.line.fill.background()
textbox(s,.75,1.20,11.8,.32,'DBMS LAB  |  END-SEMESTER SUBMISSION',10,ACCENT,True)
textbox(s,.75,1.68,11.8,.82,'Player Telemetry Analytics',32,WHITE,True)
textbox(s,.78,2.55,10.9,.42,'Executive readout, SQL analysis and churn model',16,RGBColor(218,230,238))
textbox(s,.78,3.18,11.5,.66,'Core finding: the ARPDAU decline is a mix shift toward lower-monetising markets, not a deterioration inside any country tier.',15,WHITE,True)
# Academic identification band
for x,label,value,w in [
    (.82,'SUBMITTED BY','Thirumal',2.45),
    (3.75,'ROLL NUMBER','24MAB0A25',2.25),
    (6.48,'COURSE','Database Management Systems (DBMS)',3.15),
    (10.05,'COURSE INSTRUCTOR','Dr. Vikas Srivastava',2.55)]:
    textbox(s,x,4.20,w,.22,label,8,ACCENT,True)
    textbox(s,x,4.48,w,.48,value,11,WHITE,True)
# subtle separator
rule=s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(.8), Inches(5.08), Inches(11.85), Inches(.012));rule.fill.solid();rule.fill.fore_color.rgb=RGBColor(55,82,104);rule.line.fill.background()
metrics=[('80,295','player profiles'),('667,435','active player-days'),('15,426','purchase events'),('647,623','ad interactions')]
for i,(v,l) in enumerate(metrics):
    x=.8+i*3.05;textbox(s,x,5.38,2.6,.45,v,23,WHITE,True);textbox(s,x,5.88,2.7,.25,l,10,MUTED)
textbox(s,.8,6.68,11,.25,'Analysis window: 1 Jan–30 Apr 2026  |  Submission deadline: 25 Nov 2026',9,MUTED)

# 2 acquisition mix
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','The audience changed faster than monetisation did','New installs accelerated sharply in March–April, driven by paid video and a large Tier 4 mix.',2)
image(s,C/'install_mix.png',.55,1.78,7.3,4.55)
bullet_list(s,8.15,2.02,4.5,[
 '64,295 installs landed during the 120-day window.',
 'Monthly installs rose from 9,809 in January to 26,806 in April (+173%).',
 'Paid video rose from 15.1% of January installs to 69.2% in April.',
 'Tier 4 reached 62.7% of April installs, versus 18.1% in January.'
],13,.88)
note(s,8.18,5.92,4.3,.65,'Paid-video installs are 75.3% Tier 4; organic and paid social are each about 18.5% Tier 4.',11)

# 3 ARPDAU paradox
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','The 16.3% ARPDAU decline is a composition effect','All four country tiers improved or stayed flat; the active-player mix shifted toward Tier 4.',3)
image(s,C/'tier_arpdau.png',.55,1.8,6.0,3.55);image(s,C/'tier_mix.png',6.75,1.8,6.0,3.55)
textbox(s,.75,5.58,3.6,.35,'Overall ARPDAU',11,GREY,True)
textbox(s,.75,5.92,3.7,.48,f"${over.loc['first30','arpdau']:.3f}  →  ${over.loc['last30','arpdau']:.3f}  ({(over.loc['last30','arpdau']/over.loc['first30','arpdau']-1):.1%})",19,NAVY,True)
textbox(s,4.65,5.58,3.65,.35,'Fixed-mix counterfactual',11,GREY,True)
textbox(s,4.65,5.92,3.9,.48,'$0.385 ARPDAU (+8.0%)',19,TEAL,True)
textbox(s,8.75,5.58,3.9,.35,'Decomposition (USD / player-day)',11,GREY,True)
textbox(s,8.75,5.92,3.95,.55,'Tier performance +$0.0284\nMix shift −$0.0866',14,NAVY,True)
note(s,.75,6.58,11.7,.3,'Recommendation: do not launch a blanket monetisation “fix”. Report mix-adjusted ARPDAU and review the economics of the new Tier 4 acquisition mix.',10)

# 4 channel quality
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','Channel quality differs on engagement; revenue is not settled','Compare first 30 days after install for Jan–Mar cohorts with complete follow-up; adjust for tier, platform and install week.',4)
rows=[]
for ch in ['organic','paid_social','paid_video']:
 r=channel.loc[ch]
 rows.append([ch.replace('_',' '),f"{int(r.players):,}",f"{r.avg_active_days_30:.2f}",f"${r.revenue_per_install_30:.2f}",f"{r.payer_rate_30:.1%}"])
table(s,.65,1.83,5.85,2.0,['Channel','N','Active days / 30','Gross revenue / install','Payer rate'],rows,[1.35,.75,1.35,1.35,1.05],10)
image(s,C/'channel_adjusted.png',7.95,1.82,4.8,2.05)
bullet_list(s,.8,4.08,11.8,[
 'Adjusted engagement: paid social −0.212 days (95% CI −0.286 to −0.137); paid video −0.295 (−0.378 to −0.213). Both significant.',
 'Adjusted 30-day gross revenue/install: paid social −$0.254 (CI −$0.535 to +$0.027; p=.076); paid video −$0.162 (CI −$0.469 to +$0.146; p=.303). Neither significant.',
 'Decision: do not reallocate budget on raw revenue/install. Paid video has a small engagement deficit, but the revenue gap is not resolved after mix adjustment.'
],11,.66)

# 5 retention and payer economics
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','Retention is low and revenue is concentrated','The long-tail monetisation model depends on a relatively small payer population.',5)
image(s,C/'retention_heatmap.png',.55,1.78,6.5,4.45)
image(s,C/'revenue_concentration.png',7.35,1.95,5.2,2.6)
bullet_list(s,7.55,4.75,5.0,[
 'Pooled retention: D1 47.6% · D7 25.4% · D14 19.5% · D30 13.9%.',
 '11,054 / 80,295 profiles paid (13.8%); 86.2% never paid.',
 'Median time to first purchase: 22 days; median repeat-purchase gap: 15.0 days.'
],11,.62)

# 6 ads
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','Rewarded-ad caps are rarely reached','Use completed ad views for cap analysis; daily totals mostly track the expanding active audience.',6)
image(s,C/'daily_ads.png',.55,1.78,7.3,4.65)
rows=[[str(int(r.cap)),f"{int(r.player_days):,}",f"{int(r.hit_cap_days):,}",f"{r.share_hit_cap:.3%}"] for r in cap.itertuples()]
table(s,8.05,2.05,4.65,1.55,['Cap','Player-days','Hit cap','Share'],rows,[.8,1.35,1.0,1.2],10)
bullet_list(s,8.15,4.05,4.35,[
 'Overall cap-hit rate: 0.79% of completed-ad player-days.',
 'No ad rows on 6 Mar despite active players; treat as a telemetry gap, not zero demand.',
 '7,732 ad rows dated 1 May are outside the stated window and excluded.'
],11,.78)

# 7 churn
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','A simple churn model ranks risk, but offer waste remains high','Churn = no activity in the 14 days after a snapshot, among players active in the prior 7 days.',7)
image(s,C/'churn_targeting.png',.6,1.8,7.0,4.4)
textbox(s,8.0,1.98,4.5,.3,'TEMPORAL HOLDOUT · 16 APR 2026',10,TEAL,True)
textbox(s,8.0,2.4,4.2,.45,'28,321',25,NAVY,True);textbox(s,8.0,2.85,4.2,.25,'active players scored',11,GREY)
textbox(s,8.0,3.35,4.2,.45,'69.7%',25,NAVY,True);textbox(s,8.0,3.8,4.2,.25,'ROC-AUC · PR-AUC 0.386 vs 0.233 baseline',11,GREY)
textbox(s,8.0,4.35,4.4,.45,'45.5%',25,NAVY,True);textbox(s,8.0,4.8,4.3,.35,'top-decile precision; 54.5% of offers still go to non-churners',11,GREY)
note(s,8.0,5.6,4.4,.8,'Pilot the top 5–10% only if expected incremental retained margin exceeds offer cost. Risk is not treatment uplift; run a randomized holdout.',11)

# 8 recommendations
s=prs.slides.add_slide(BLANK);header(s,'Executive readout','What we recommend next','The data supports targeted follow-up, not a broad monetisation intervention.',8)
bullet_list(s,.85,1.95,11.6,[
 'Reframe the ARPDAU dashboard: show actual and fixed-tier-mix ARPDAU side by side; investigate the Tier 4 acquisition surge.',
 'Do not shift paid acquisition budget on raw 30-day revenue. Run a channel experiment or matched holdout with country-tier and platform balance.',
 'Keep rewarded-ad caps unchanged for now; repair the 6 March telemetry gap and validate cap changes before making a product decision.',
 'Pilot churn offers on the highest-risk 5–10% with randomized treatment/control, and calculate incremental margin after offer cost.',
 'Next data needed: marketing spend/CPI by channel, ad-network revenue, offer cost and uplift, and player-level account identity resolution.'
],14,.91)
note(s,.85,6.55,11.4,.3,'Selected deep dive: 2(a) ARPDAU. The alternative sales-frequency question (2b) and optional 90-day LTV model (4b) were not selected.',10)

# 9 appendix data audit
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 1','Data inventory and key quality checks','Five supplied files cover 120 days of telemetry; two PDF exports were reconstructed into row-aligned CSVs.',9)
rows=[['player_profile','80,295','1 row / device'],['player_day','667,435','unique device-day'],['purchase','15,426','purchase events'],['currency_spend','489,892','currency spend events'],['ad_view','647,623','ad interactions incl. out-of-window']]
table(s,.65,1.85,5.65,2.0,['Table','Rows','Grain'],rows,[1.65,1.25,2.75],10)
bullet_list(s,6.75,1.9,5.8,[
 '16,000 profiles were installed before 1 Jan; retained for historical DAU but excluded from new-install cohort analyses.',
 '3,211 rows have original_device_id links; device_id retained as the stated key because links include inconsistent chronology.',
 'No duplicate device-day rows in player_day.',
 '122 purchase_id values collide across distinct event timestamps; do not deduplicate on purchase_id.',
 '228 negative purchase rows (−$3,274.72); included as signed revenue adjustments, not silently dropped.',
 '110 first_purchase_date values precede install_date; excluded from time-to-first-purchase distribution.',
 '110 currency-spend device/timestamp collisions and 277 zero-value events; retain events, do not deduplicate by timestamp.',
 '2,429 positive-purchase player-days have no same-day player_day row; revenue is retained, but these are excluded from active-payer share.'
],10.5,.67)

# 10 daily health
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 1(a)','Daily health: platform split','SQL output includes daily DAU, signed purchase revenue, ARPDAU and payer share of DAU.',10)
image(s,C/'daily_arpdau_platform.png',.65,1.8,7.3,4.35)
rows=[['Android','$113,593.75','458,578','$0.248','1.43%'],['iOS','$105,840.27','208,857','$0.507','2.86%']]
table(s,8.25,2.15,4.35,1.65,['Platform','Revenue','Player-days','ARPDAU','Payer share'],rows,[.9,1.1,1.0,.75,.85],9)
note(s,8.3,4.2,4.15,1.0,'Platform totals aggregate over the full window. ARPDAU uses positive gross purchase revenue; negative adjustments are shown separately in the daily output.',11)

# 11 retention
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 1(b)','Retention cohorts and right-censoring','Install-week cohorts are shown down the rows; milestone day is exact activity on install_date + N.',11)
image(s,C/'retention_heatmap.png',.65,1.8,7.4,4.7)
ret_summary=[]
for m,g in ret.groupby('milestone_day'):
 ret_summary.append([f'Day {m}',f"{int(g.active_n.sum()):,}",f"{int(g.eligible_n.sum()):,}",f"{g.active_n.sum()/g.eligible_n.sum():.1%}"])
table(s,8.35,2.1,4.2,2.1,['Milestone','Active','Eligible','Pooled'],ret_summary,[1.0,1.0,1.1,1.1],10)
note(s,8.35,4.55,4.1,1.0,'Rule: recent cohort cells are NULL when the milestone date is after 30 Apr. This avoids treating unobserved future activity as churn.',11)

# 12 spender behaviour
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 1(c)','Spender behaviour','Payer population = players with at least one positive purchase; concentration is ranked on positive gross revenue.',12)
rows=[[f"Top {int(r.top_share*100)}%",f"{int(r.players):,}",f"{r.gross_revenue_share:.1%}"] for r in conc.itertuples()]
table(s,.7,1.95,4.6,1.65,['Payer segment','Players','Gross revenue share'],rows,[1.45,1.2,1.95],11)
# ttf table
rows=[]
for r in ttf.itertuples(): rows.append([r.days_after_install,int(r.players),f'{r.share_of_payers_valid:.1%}'])
table(s,5.7,1.85,3.35,3.8,['Days to first purchase','Players','Valid payer share'],rows,[1.6,.8,.95],8)
bullet_list(s,9.35,2.0,3.35,[
 '10,944 valid payers; 110 first-purchase dates precede install.',
 '86.2% of all profiles have no first_purchase_date.',
 '2,539 repeat buyers; 4,144 consecutive gaps.',
 'Gap median 15.0 days; mean 22.1 days; IQR 5.7–32.0.'
],10.5,.9)

# 13 ads appendix
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 1(d)','Rewarded ads: daily trend and cap behaviour','Cap hit = any completed event on a player-day with ad_daily_count >= contemporaneous ad_daily_cap.',13)
image(s,C/'daily_ads.png',.65,1.8,7.2,4.6)
rows=[[str(int(r.cap)),f'{int(r.player_days):,}',f'{int(r.hit_cap_days):,}',f'{r.share_hit_cap:.3%}'] for r in cap.itertuples()]
table(s,8.15,2.0,4.45,1.6,['Cap','Player-days','Hits','Rate'],rows,[.7,1.35,1.0,1.1],10)
note(s,8.2,4.05,4.25,1.35,'6,160 completed-ad player-days show more than one cap value during the day. The day is grouped by the cap on the event with peak ad_daily_count; sensitivity should be checked against event-level cap history.',10.5)

# 14 ARPDAU detail
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 2(a)','Tier-level ARPDAU decomposition','ARPDAU denominator is summed daily active players (player-days), not distinct monthly users.',14)
rows=[]
for tier_id in [1,2,3,4]:
 a=tier[(tier.country_tier==tier_id)&(tier.period=='first30')].iloc[0];b=tier[(tier.country_tier==tier_id)&(tier.period=='last30')].iloc[0]
 rows.append([tier_id,f"${a.arpdau:.3f}",f"${b.arpdau:.3f}",f"{(b.arpdau/a.arpdau-1):+.1%}",f'{a.dau_mix:.1%}',f'{b.dau_mix:.1%}'])
table(s,.75,1.95,7.0,2.2,['Tier','Jan ARPDAU','Apr ARPDAU','Change','Jan DAU mix','Apr DAU mix'],rows,[.75,1.25,1.25,1.0,1.3,1.3],10)
image(s,C/'tier_arpdau.png',8.15,1.9,4.5,2.54)
bullet_list(s,.9,4.65,11.6,[
 'Overall gross ARPDAU: $0.3567 → $0.2985 (−16.3%). Tier 1 +7.0%; Tier 2 +8.5%; Tier 3 +13.5%; Tier 4 +2.0%.',
 f'Holding the January DAU mix fixed, April tier ARPDAUs imply ${summary["arpdau_decomposition"]["last30_rates_at_first30_mix"]:.4f} (+{(summary["arpdau_decomposition"]["last30_rates_at_first30_mix"]/summary["arpdau_decomposition"]["first30_rates_at_first30_mix"]-1):.1%}). Actual April mix gives ${over.loc["last30","arpdau"]:.4f}.',
 'Mix effect = −$0.0866 per DAU-day; within-tier effect = +$0.0284. This is a weighted decomposition, not a causal estimate.'
],11,.62)

# 15 channel details
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 3','Channel comparison: raw and adjusted evidence','First 30 days after install; installs from 1 Jan–31 Mar only, so all players have a full 30-day observation window.',15)
rows=[]
for ch in ['organic','paid_social','paid_video']:
 r=channel.loc[ch]
 rows.append([ch.replace('_',' '),f'{int(r.players):,}',f'{r.avg_active_days_30:.2f}',f'${r.revenue_per_install_30:.2f}',f'{r.payer_rate_30:.1%}',f'{r.d7_retention:.1%}'])
table(s,.65,1.85,7.0,1.7,['Channel','N','Active days','Gross rev / install','Payer rate','D7'],rows,[1.25,.7,1.15,1.35,1.0,.8],9)
image(s,C/'channel_adjusted.png',7.95,1.82,4.8,2.05)
rows=[]
for _,r in reg[reg.metric.isin(['active_days_30','revenue_30'])].iterrows():
 label='Paid social' if 'paid_social' in r.term else 'Paid video'
 metric='Active days' if r.metric=='active_days_30' else 'Gross revenue / install'
 rows.append([metric,label,f"{r.coef:+.3f}",f"[{r.ci_low:+.3f}, {r.ci_high:+.3f}]",f"{r.p_value:.3g}"])
table(s,.75,4.0,11.8,1.65,['Adjusted outcome','Comparison vs organic','Difference','95% CI','p-value'],rows,[2.0,2.25,1.4,3.1,1.0],9)
note(s,.8,5.95,11.6,.55,'Controls: country_tier, platform and install week; OLS with HC3 robust standard errors. Channel is observational, not randomized. Paid video is 75.3% Tier 4, versus 18.5% for organic.',10.5)

# 16 churn details
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Deliverable 4','Churn model: setup, temporal evaluation and targeting trade-off','Logistic regression; train on snapshots through 19 Mar, test on the 16 Apr snapshot. The final test horizon is fully observed through 29 Apr.',16)
textbox(s,.8,1.85,3.3,.3,'PREDICTION SETUP',10,TEAL,True)
bullet_list(s,.85,2.2,3.3,[
 'Eligible: installed at least 14 days before snapshot and active in prior 7 days.',
 'Label: zero active days in next 14 days.',
 'Features: 7/30-day sessions, playtime, activity, recency, purchases, currency-spend and ad interactions; plus platform, tier and channel.'
],10,.75)
textbox(s,4.55,1.85,3.3,.3,'TEMPORAL TEST RESULTS',10,TEAL,True)
bullet_list(s,4.6,2.2,3.4,[
 'Train rows: 124,071 across 9 snapshots.',
 'Test rows: 28,321; churn rate 23.3%.',
 'ROC-AUC 0.697; PR-AUC 0.386 vs 0.233 prevalence baseline; Brier 0.164.'
],10,.75)
textbox(s,8.4,1.85,3.7,.3,'TOP-RISK TARGETING',10,TEAL,True)
rows=[]
for frac in [.05,.1,.2]:
 r=threshold[threshold.target_fraction_num==frac].iloc[0]
 rows.append([f'{frac:.0%}',f'{int(r.players_targeted):,}',f'{r.precision_churn:.1%}',f'{r.recall_churn:.1%}',f'{r.wasted_offer_share:.1%}'])
table(s,8.35,2.2,4.25,1.7,['Target','Players','Precision','Recall','Waste'],rows,[.65,1.0,.9,.8,.8],9)
image(s,C/'churn_targeting.png',.8,4.55,7.4,2.1)
note(s,8.45,4.35,4.1,1.4,'No 0.50 probability threshold is useful here: predicted probabilities top out below 0.50. Choose a capacity/economics-based top-risk fraction, then randomize eligible offers to estimate incremental uplift.',10.5)

# 17 data quality and limitations
s=prs.slides.add_slide(BLANK);header(s,'Appendix · Judgement calls','What the data cannot settle','The analysis avoids silently turning missing, duplicated or right-censored data into business conclusions.',17)
bullet_list(s,.85,1.9,11.7,[
 'Identity: 3,211 profiles have original_device_id links (3,099 canonical duplicate groups). device_id is retained as the stated analysis key; account-level deduplication needs an authoritative identity map.',
 'Purchase events: 122 purchase_id collisions have distinct timestamps; 228 negative USD rows are retained as signed adjustments. A unique transaction key is not reliable in this extract.',
 'Retention and channel analysis: installs before 1 Jan are left-truncated; channel comparison uses Jan–Mar installs with complete 30-day follow-up. Cohort cells without full follow-up are NULL.',
 'Ads: 7,732 records on 1 May are outside the 120-day window; 6 Mar has no ad rows despite active players; 6,160 completed-ad player-days contain multiple cap values.',
 'Currency spend has 110 same-device/same-timestamp collisions and 277 zero-value events; no negative currency values or balances were found.',
 '2,429 positive-purchase player-days have no same-day activity row; gross revenue remains in the revenue total, while the daily active-payer numerator is restricted to the DAU set.',
 'Causal limits: no marketing cost/CPI, ad revenue, offer cost/uplift, support tickets or surveys. Channel comparisons are adjusted associations, not causal ROI; churn scores are risk, not treatment response.'
],10.5,.66)
note(s,.85,6.45,11.6,.35,'If given another week: validate identity stitching, resolve ad telemetry, obtain UA spend and ad-network revenue, and run randomized channel/offer holdouts.',10.5)

prs.save(OUT)
print('Wrote',OUT,'slides',len(prs.slides))
