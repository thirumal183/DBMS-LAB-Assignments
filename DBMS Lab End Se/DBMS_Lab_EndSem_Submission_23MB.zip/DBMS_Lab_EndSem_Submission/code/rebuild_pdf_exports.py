"""Rebuild player_profile.csv and purchase.csv from the supplied split-column PDFs.

Requires Poppler's pdftotext executable. The source PDFs print wide tables in
paired pages: the first page contains the left columns and the next page the
rightmost columns. This script restores row alignment within each page pair.
"""
from pathlib import Path
import argparse, csv, re, subprocess, tempfile

def lines(page):
    return [x.strip() for x in page.splitlines() if x.strip()]

def profile(pdf, out):
    with tempfile.TemporaryDirectory() as td:
        txt=Path(td)/'profile.txt'
        subprocess.run(['pdftotext','-raw',str(pdf),str(txt)],check=True)
        pages=txt.read_text().split('\f')
    rows=[]
    for i in range(0,len(pages)-1,2):
        a=[x for x in lines(pages[i]) if not x.startswith('device_id') and not x.startswith('install_date')]
        b=[x for x in lines(pages[i+1]) if x not in ('acquisition_channel','first_purchase_date')]
        if len(a)!=len(b): raise ValueError(f'Profile page pair {i+1}/{i+2}: {len(a)} vs {len(b)} rows')
        for x,y in zip(a,b):
            m=re.match(r'^(\d+)\s+(?:(\d+)\s+)?(\d{4}-\d{2}-\d{2})\s+(Android|iOS)\s+(.+?)\s+([1-4])$',x)
            if not m: raise ValueError(f'Unparsed profile row on page {i+1}: {x}')
            device,orig,inst,plat,country,tier=m.groups(); z=y.split()
            rows.append([device,orig or '',inst,plat,country,tier,z[0] if z else '',z[1] if len(z)>1 else ''])
    with open(out,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['device_id','original_device_id','install_date','platform','country','country_tier','acquisition_channel','first_purchase_date']);w.writerows(rows)
    return len(rows)

def purchases(pdf,out):
    with tempfile.TemporaryDirectory() as td:
        txt=Path(td)/'purchase.txt'
        subprocess.run(['pdftotext','-raw',str(pdf),str(txt)],check=True)
        pages=txt.read_text().split('\f')
    rows=[]
    for i in range(0,len(pages)-1,2):
        a=[x for x in lines(pages[i]) if not x.startswith('purchase_id')]
        b=[x for x in lines(pages[i+1]) if x!='sale_flag']
        trans=[];j=0
        while j<len(a):
            m=re.match(r'^(TX\w+)\s+(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2}:\d{2})$',a[j])
            if not m or j+1>=len(a): raise ValueError(f'Unparsed purchase header on page {i+1}: {a[j]}')
            n=re.match(r'^(.+?)\s+(-?[0-9]+\.[0-9]+)\s+(-?\d+)$',a[j+1])
            if not n: raise ValueError(f'Unparsed purchase details on page {i+1}: {a[j+1]}')
            trans.append(list(m.groups())+list(n.groups()));j+=2
        if len(trans)!=len(b): raise ValueError(f'Purchase page pair {i+1}/{i+2}: {len(trans)} vs {len(b)} rows')
        for r,sale in zip(trans,b): rows.append(r+[sale])
    with open(out,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['purchase_id','device_id','event_date','event_time','pack_name','usd_amount','currency_granted','sale_flag']);w.writerows(rows)
    return len(rows)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--profile-pdf',required=True);ap.add_argument('--purchase-pdf',required=True);ap.add_argument('--out-dir',required=True);args=ap.parse_args()
    out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    print('player_profile rows:',profile(args.profile_pdf,out/'player_profile.csv'))
    print('purchase rows:',purchases(args.purchase_pdf,out/'purchase.csv'))
