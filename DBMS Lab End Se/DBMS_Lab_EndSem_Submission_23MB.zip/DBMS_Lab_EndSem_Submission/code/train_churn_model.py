import pandas as pd, numpy as np, json, os
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.calibration import calibration_curve
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
B=str(ROOT/'results'); O=B
x=pd.read_csv(B+'/churn_training_panel.csv',parse_dates=['snapshot_date','install_date'])
# create deltas/ratios to make recent changes explicit
x['has_purchase_30']=(x['purchases_30']>0).astype(int)
x['log_revenue_30']=np.log1p(x['revenue_30'].clip(lower=0))
# avoid invalid negative net revenue causing weird log; still purchase count signal retained
num=['active_days_7','active_days_30','sessions_7','sessions_30','playtime_7','playtime_30','recency_days','purchases_30','days_since_purchase','ad_completions_30','ad_abandons_30','has_purchase_30','log_revenue_30','currency_spend_events_30','currency_value_spent_30','premium_value_spent_30','paid_origin_spend_events_30','free_origin_spend_events_30','subscription_origin_spend_events_30']
cat=['platform','country_tier','acquisition_channel']
# temporal split; train labels fully mature before holdout snapshot; latest snapshot held out
train=x[x.snapshot_date<=pd.Timestamp('2026-03-19')].copy()
test=x[x.snapshot_date==pd.Timestamp('2026-04-16')].copy()
pre=ColumnTransformer([('num',Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num),('cat',OneHotEncoder(handle_unknown='ignore',drop='first'),cat)])
model=Pipeline([('prep',pre),('lr',LogisticRegression(max_iter=1000,C=0.5,solver='lbfgs'))])
model.fit(train[num+cat],train.churned_14d)
prob=model.predict_proba(test[num+cat])[:,1]
y=test.churned_14d.to_numpy()
base=float(y.mean()); auc=roc_auc_score(y,prob); ap=average_precision_score(y,prob); brier=brier_score_loss(y,prob)
# top risk capture and thresholds
order=np.argsort(-prob)
rows=[]
for frac in [.05,.10,.15,.20,.25,.30]:
 n=int(np.ceil(len(test)*frac)); ix=order[:n]
 rows.append({'target_fraction':frac,'players_targeted':n,'precision_churn':float(y[ix].mean()),'recall_churn':float(y[ix].sum()/y.sum()),'wasted_offer_share':float(1-y[ix].mean()),'lift_vs_base':float(y[ix].mean()/base)})
# fixed probability thresholds
for t in [.15,.20,.25,.30,.35,.40,.50]:
 pred=(prob>=t).astype(int)
 tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
 rows.append({'target_fraction':f'threshold_{t:.2f}','players_targeted':int(pred.sum()),'precision_churn':float(tp/(tp+fp)) if tp+fp else 0,'recall_churn':float(tp/(tp+fn)),'wasted_offer_share':float(fp/(tp+fp)) if tp+fp else 0,'lift_vs_base':float((tp/(tp+fp))/base) if tp+fp else 0})
pd.DataFrame(rows).to_csv(O+'/churn_thresholds.csv',index=False)
# coefficient importance
feature_names=model.named_steps['prep'].get_feature_names_out()
coef=model.named_steps['lr'].coef_[0]
imp=pd.DataFrame({'feature':feature_names,'coefficient':coef,'odds_ratio_per_sd_or_category':np.exp(coef)}).sort_values('coefficient')
imp.to_csv(O+'/churn_model_coefficients.csv',index=False)
# calibration deciles
cal=pd.DataFrame({'actual':y,'pred':prob})
cal['decile']=pd.qcut(cal.pred,10,duplicates='drop')
cal=cal.groupby('decile',observed=True).agg(players=('actual','size'),mean_pred=('pred','mean'),actual_rate=('actual','mean')).reset_index()
cal['decile']=cal.decile.astype(str);cal.to_csv(O+'/churn_calibration.csv',index=False)
# output summary
out={'train_rows':len(train),'train_snapshots':sorted(train.snapshot_date.dt.strftime('%Y-%m-%d').unique().tolist()),'test_rows':len(test),'test_snapshot':'2026-04-16','test_churn_rate':base,'roc_auc':auc,'average_precision':ap,'brier_score':brier,'baseline_ap':base,'baseline_precision_at_10pct':base,'top_decile_precision':float(y[order[:int(np.ceil(len(test)*.1))]].mean()),'top_decile_recall':float(y[order[:int(np.ceil(len(test)*.1))]].sum()/y.sum()),'test_players':len(test),'model':'LogisticRegression(C=0.5), scaled numeric + one-hot categorical; no class weights'}
with open(O+'/churn_model_summary.json','w') as f:json.dump(out,f,indent=2)
print(json.dumps(out,indent=2));print('\nTHRESHOLDS\n',pd.DataFrame(rows).to_string(index=False));print('\nCOEFS\n',imp.to_string(index=False));print('\nCAL\n',cal.to_string(index=False))
