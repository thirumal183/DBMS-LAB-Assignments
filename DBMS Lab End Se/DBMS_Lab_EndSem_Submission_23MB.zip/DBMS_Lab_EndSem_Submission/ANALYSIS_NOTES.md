# Analysis notes and findings

## Executive conclusion

The apparent ARPDAU decline is a Simpson's-paradox-style composition effect. Gross ARPDAU fell from **$0.3567** in 1–30 January to **$0.2985** in 1–30 April (**−16.3%**), while all four country tiers improved. The active-player mix shifted sharply toward Tier 4, which has lower ARPDAU. Holding the January tier mix fixed, April's tier-level ARPDAUs imply **$0.3851** ARPDAU (**+8.0%** versus January). The within-tier improvement is **+$0.0284** per player-day, offset by a **−$0.0866** mix effect.

The shift coincides with an acquisition change: monthly installs grew from **9,809** in January to **26,806** in April. Paid video grew from **1,480** installs in January to **18,563** in April and accounted for **69.2%** of April installs. **75.3%** of paid-video installs are Tier 4, versus **18.5%** for organic and **18.4%** for paid social.

## Deliverable 1 — SQL data exploration

### 1(a) Daily health

- DAU is the distinct `device_id` with activity that date.
- Gross revenue is positive purchase USD only; negative rows are reported separately as adjustments. Gross ARPDAU uses gross revenue / daily active player-days.
- Full-window platform roll-up:

| Platform | Gross purchase revenue | Active player-days | Gross ARPDAU | Payer share of DAU |
|---|---:|---:|---:|---:|
| Android | $113,593.75 | 458,578 | $0.248 | 1.43% |
| iOS | $105,840.27 | 208,857 | $0.507 | 2.86% |

Negative purchase adjustments total **−$3,274.72** (Android −$1,655.88; iOS −$1,618.84). Signed net purchase revenue is **$216,159.30**, compared with positive gross purchase revenue of **$219,434.02**. Daily payer share counts only purchasers who also have a same-day `player_day` row; **2,429** positive-purchase player-days lack same-day activity telemetry. Their revenue remains in the revenue numerator, but they are not counted as active payers.

### 1(b) Retention

Pooled exact-day retention across cohorts with observable milestones:

| Milestone | Retained | Eligible | Retention |
|---|---:|---:|---:|
| Day 1 | 30,181 | 63,353 | 47.6% |
| Day 7 | 14,641 | 57,637 | 25.4% |
| Day 14 | 9,988 | 51,151 | 19.5% |
| Day 30 | 5,204 | 37,489 | 13.9% |

Cohorts before 1 January are not used in the cohort grid because the extract does not contain their install-period activity. Recent cohorts contribute only to milestones fully observable by 30 April.

### 1(c) Spender behaviour

- Payers: **11,054** players with at least one positive purchase.
- Gross revenue concentration, ranking payers by positive gross revenue: top 1% (**111 players**) contribute **9.39%**; top 10% (**1,106**) contribute **47.79%**; top 50% (**5,527**) contribute **89.96%**.
- **69,241 / 80,295 (86.23%)** have no `first_purchase_date`. Among the 10,944 valid first-purchase dates, median time to first purchase is **22 days** (P25 6 days, P75 69 days). Another 110 profile dates precede install and are excluded as invalid.
- **2,539** players made more than one positive purchase, producing **4,144** consecutive gaps. Median gap is **14.98 days**; mean 22.05 days; interquartile range 5.73–32.02 days.

### 1(d) Rewarded ads

- **396,825** player-days contained at least one completed ad view.
- Cap 5: **3,117 / 297,862 = 1.046%** of completed-ad player-days hit cap.
- Cap 8: **14 / 98,963 = 0.014%** hit cap.
- Overall: **3,131 / 396,825 = 0.789%**.
- Daily all-status ad interactions rise from 536 on 1 January to 11,826 on 30 April. The increase largely tracks the growing DAU base; interactions per DAU are around 0.9–1.07 for most of the window after the unusually low first day.
- There are no `ad_view` rows on 6 March despite player activity, so the date is treated as a telemetry gap, not zero demand. Another 7,732 ad rows are dated 1 May and excluded from the 120-day analysis.
- 6,160 completed-ad player-days contain more than one cap value during the day. The main calculation uses the cap attached to the event with the peak count and flags the inconsistency for validation.

## Deliverable 2(a) — ARPDAU is falling

The first 30 days are 1–30 January and the last 30 days are 1–30 April. The denominator is summed daily active players, not unique players across the month.

| Country tier | Jan gross ARPDAU | Apr gross ARPDAU | Change | Jan DAU mix | Apr DAU mix |
|---|---:|---:|---:|---:|---:|
| 1 | $0.5235 | $0.5602 | +7.0% | 34.5% | 20.4% |
| 2 | $0.3754 | $0.4073 | +8.5% | 26.1% | 15.6% |
| 3 | $0.2339 | $0.2654 | +13.5% | 21.8% | 18.0% |
| 4 | $0.1552 | $0.1582 | +2.0% | 17.7% | 46.0% |

The weighted decomposition is:

- Within-tier change at January mix: **+$0.0284** per DAU-day.
- Mix change at April tier rates: **−$0.0866** per DAU-day.
- Net change: **−$0.0582**, from $0.3567 to $0.2985.

Recommendation: do not apply a blanket monetisation fix. Report actual and fixed-tier-mix ARPDAU together; investigate the economics and targeting of the Tier 4 acquisition surge. This is a descriptive decomposition, not a causal attribution.

## Deliverable 3 — Acquisition channel quality

The comparison uses 37,489 installs from January–March, each with a complete 30-day post-install observation window. Metrics are player-level averages and include zero-revenue players.

| Channel | Players | Active days / 30 | Gross revenue / install | Payer rate | D7 retention |
|---|---:|---:|---:|---:|---:|
| Organic | 12,948 | 7.07 | $2.50 | 13.3% | 26.4% |
| Paid social | 11,511 | 6.86 | $2.25 | 13.2% | 25.6% |
| Paid video | 13,030 | 6.82 | $1.55 | 8.9% | 24.6% |

Adjusted differences versus organic, controlling for country tier, platform and install week (HC3 robust OLS):

- Active days: paid social **−0.212** (95% CI −0.286 to −0.137, p<0.001); paid video **−0.295** (−0.378 to −0.213, p<0.001). These differences are statistically significant but small in practical terms (about 0.2–0.3 days in 30 days).
- Gross revenue per install: paid social **−$0.254** (95% CI −$0.535 to +$0.027, p=0.076); paid video **−$0.162** (−$0.469 to +$0.146, p=0.303). Neither is statistically significant after adjustment.

The raw paid-video revenue gap is strongly confounded by its Tier 4 mix (75.3% Tier 4). There is evidence of a small engagement difference, but the sample does not resolve a revenue difference after adjustment. Channel is not randomized and CPI/marketing spend is absent, so these results do not support a causal budget ROI claim.

## Deliverable 4 — Churn model

- **Prediction population:** players installed at least 14 days before a snapshot and active at least once in the prior 7 days.
- **Label:** no activity in the 14 days beginning on the snapshot date.
- **Features:** activity days, sessions, playtime, recency, positive purchase count/net revenue, currency-spend counts/values and ad completions/abandons in recent windows, plus platform, country tier and acquisition channel.
- **Temporal split:** train on 124,071 player-snapshot rows through 19 March; hold out the 16 April snapshot (28,321 active players). Training labels end by 2 April; test labels are fully observed through 29 April.
- **Test churn prevalence:** 23.28%; ROC-AUC **0.697**; PR-AUC **0.386** versus 0.233 prevalence baseline; Brier score **0.164**.
- **Top decile:** 2,833 players targeted; 45.5% actually churned (precision), capturing 19.6% of all churners (recall). 54.5% would not churn in the next 14 days without treatment, a practical proxy for offers that may not be needed.

Recommendation: start with a 5–10% risk-ranked pilot only if the expected incremental retained margin exceeds offer cost. A churn-risk model does not predict who responds to an offer; randomize offers with a holdout and estimate incremental lift before scaling.

## Data-quality issues and handling

- `player_day` has no duplicate `(device_id, activity_date)` rows.
- 16,000 profiles predate the telemetry window; used for historical active base but not new-install cohort/channel comparisons.
- 3,211 profiles contain `original_device_id` links (3,099 canonical duplicate groups). `device_id` is retained as the analysis key because the source describes it as the player identifier and some link chronology is inconsistent; authoritative identity stitching is needed for account-level reporting.
- 122 `purchase_id` values collide across distinct timestamps; events are not deduplicated by ID.
- 228 negative purchase rows (−$3,274.72) are retained as signed adjustments; positive-only gross revenue is used for gross ARPDAU and concentration.
- 110 `first_purchase_date` values precede `install_date`; excluded from time-to-first-purchase calculations.
- 2,429 positive-purchase player-days have no same-day `player_day` row; revenue remains included, but those devices are excluded from the active-payer numerator.
- `currency_spend` has 110 same-device/same-timestamp collisions and 277 zero-value events; these are retained as events. No negative currency values or negative balances were found. Currency-spend count/value features are included in the churn model.
- 7,732 ad rows fall on 1 May; excluded. 6 March has no ad rows despite active users; flagged as telemetry gap.
- 6,160 completed-ad player-days have multiple `ad_daily_cap` values; reported using the cap at peak count and flagged for follow-up.
- Missing inputs: marketing spend/CPI by channel, ad-network revenue, offer cost and treatment uplift, support tickets and survey data.
