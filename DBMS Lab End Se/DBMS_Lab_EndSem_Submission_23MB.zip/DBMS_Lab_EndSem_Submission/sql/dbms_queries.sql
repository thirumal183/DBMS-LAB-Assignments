-- DBMS LAB END-SEM | SQLite 3.25+ (window functions required)
-- Tables are loaded by code/load_sqlite.py from ../data/*.csv.
-- Dates in player_day.activity_date are integer YYYYMMDD.
-- Gross revenue uses positive usd_amount only; negative rows are separately exposed as adjustments and net revenue.

/* ------------------------------------------------------------------
   1(a) DAILY HEALTH BY DATE AND PLATFORM
   DAU = distinct device_id active that date.
   Gross revenue = sum of positive purchase USD amounts; negative adjustments are reported separately.
   Daily payer share = distinct devices with a positive purchase / DAU.
   ------------------------------------------------------------------ */
WITH daily_active AS (
    SELECT date(substr(CAST(d.activity_date AS TEXT),1,4) || '-' ||
                substr(CAST(d.activity_date AS TEXT),5,2) || '-' ||
                substr(CAST(d.activity_date AS TEXT),7,2)) AS activity_date,
           p.platform,
           COUNT(DISTINCT d.device_id) AS dau
    FROM player_day d
    JOIN player_profile p ON p.device_id = d.device_id
    GROUP BY 1, 2
), daily_purchase AS (
    SELECT date(pu.event_date) AS activity_date,
           pr.platform,
           SUM(CASE WHEN pu.usd_amount > 0 THEN pu.usd_amount ELSE 0 END) AS gross_revenue,
           SUM(CASE WHEN pu.usd_amount < 0 THEN pu.usd_amount ELSE 0 END) AS negative_adjustments,
           SUM(pu.usd_amount) AS net_revenue_signed
    FROM purchase pu
    JOIN player_profile pr ON pr.device_id = pu.device_id
    WHERE date(pu.event_date) BETWEEN '2026-01-01' AND '2026-04-30'
    GROUP BY 1, 2
), active_payers AS (
    SELECT date(pu.event_date) AS activity_date, pr.platform,
           COUNT(DISTINCT pu.device_id) AS daily_payers
    FROM purchase pu
    JOIN player_day d ON d.device_id = pu.device_id
      AND date(substr(CAST(d.activity_date AS TEXT),1,4) || '-' ||
               substr(CAST(d.activity_date AS TEXT),5,2) || '-' ||
               substr(CAST(d.activity_date AS TEXT),7,2)) = date(pu.event_date)
    JOIN player_profile pr ON pr.device_id = pu.device_id
    WHERE pu.usd_amount > 0
      AND date(pu.event_date) BETWEEN '2026-01-01' AND '2026-04-30'
    GROUP BY 1, 2
)
SELECT a.activity_date, a.platform, a.dau,
       COALESCE(p.gross_revenue, 0) AS gross_revenue,
       COALESCE(p.negative_adjustments, 0) AS negative_adjustments,
       COALESCE(p.net_revenue_signed, 0) AS net_revenue_signed,
       ROUND(COALESCE(p.gross_revenue, 0) / NULLIF(a.dau, 0), 6) AS arpdau,
       COALESCE(ap.daily_payers, 0) AS daily_payers,
       ROUND(COALESCE(ap.daily_payers, 0) * 1.0 / NULLIF(a.dau, 0), 6) AS payer_share_of_dau
FROM daily_active a
LEFT JOIN daily_purchase p
  ON p.activity_date = a.activity_date AND p.platform = a.platform
LEFT JOIN active_payers ap
  ON ap.activity_date = a.activity_date AND ap.platform = a.platform
ORDER BY a.activity_date, a.platform;

/* ------------------------------------------------------------------
   1(b) INSTALL-WEEK RETENTION COHORTS
   Day N means exact activity on install_date + N days (install day = day 0).
   Only players whose milestone date is on/before 2026-04-30 enter that
   milestone's denominator. Recent, right-censored cells are therefore NULL.
   Install cohorts before 2026-01-01 are excluded because earlier activity
   is not present in the 120-day player_day extract (left truncation).
   ------------------------------------------------------------------ */
WITH RECURSIVE milestones(day_n) AS (VALUES (1),(7),(14),(30)),
cohort_players AS (
    SELECT device_id, date(install_date) AS install_date,
           date(install_date, '-' || ((CAST(strftime('%w', install_date) AS INTEGER) + 6) % 7) || ' days') AS cohort_week
    FROM player_profile
    WHERE date(install_date) BETWEEN '2026-01-01' AND '2026-04-30'
), evaluated AS (
    SELECT c.cohort_week, m.day_n, c.device_id,
           CASE WHEN date(c.install_date, '+' || m.day_n || ' days') <= '2026-04-30' THEN 1 ELSE 0 END AS eligible,
           CASE WHEN EXISTS (
               SELECT 1 FROM player_day d
               WHERE d.device_id = c.device_id
                 AND date(substr(CAST(d.activity_date AS TEXT),1,4) || '-' ||
                          substr(CAST(d.activity_date AS TEXT),5,2) || '-' ||
                          substr(CAST(d.activity_date AS TEXT),7,2))
                     = date(c.install_date, '+' || m.day_n || ' days')
           ) THEN 1 ELSE 0 END AS active_on_milestone
    FROM cohort_players c CROSS JOIN milestones m
)
SELECT cohort_week, day_n,
       COUNT(*) AS cohort_installs,
       SUM(eligible) AS eligible_players,
       SUM(CASE WHEN eligible = 1 THEN active_on_milestone ELSE 0 END) AS retained_players,
       ROUND(1.0 * SUM(CASE WHEN eligible = 1 THEN active_on_milestone ELSE 0 END)
             / NULLIF(SUM(eligible), 0), 6) AS retention_rate
FROM evaluated
GROUP BY cohort_week, day_n
ORDER BY cohort_week, day_n;

/* ------------------------------------------------------------------
   1(c)(i) REVENUE CONCENTRATION
   Population ranked: all players with >=1 positive purchase. Each player's
   ranking value is each payer’s positive purchase revenue. Denominator is total positive purchase revenue.
   ------------------------------------------------------------------ */
WITH payer_revenue AS (
    SELECT device_id,
           SUM(CASE WHEN usd_amount > 0 THEN usd_amount ELSE 0 END) AS gross_revenue,
           SUM(CASE WHEN usd_amount > 0 THEN 1 ELSE 0 END) AS positive_purchase_count
    FROM purchase
    GROUP BY device_id
    HAVING SUM(CASE WHEN usd_amount > 0 THEN 1 ELSE 0 END) > 0
), ranked AS (
    SELECT device_id, gross_revenue,
           ROW_NUMBER() OVER (ORDER BY gross_revenue DESC, device_id) AS rn,
           COUNT(*) OVER () AS payer_count
    FROM payer_revenue
), totals AS (SELECT SUM(CASE WHEN usd_amount > 0 THEN usd_amount ELSE 0 END) AS total_gross_revenue FROM purchase)
SELECT payer_count,
       SUM(CASE WHEN rn <= MAX(1, CAST(payer_count * 0.01 + 0.999999 AS INTEGER)) THEN gross_revenue ELSE 0 END)
           / (SELECT total_gross_revenue FROM totals) AS top_1pct_gross_revenue_share,
       SUM(CASE WHEN rn <= MAX(1, CAST(payer_count * 0.10 + 0.999999 AS INTEGER)) THEN gross_revenue ELSE 0 END)
           / (SELECT total_gross_revenue FROM totals) AS top_10pct_gross_revenue_share,
       SUM(CASE WHEN rn <= MAX(1, CAST(payer_count * 0.50 + 0.999999 AS INTEGER)) THEN gross_revenue ELSE 0 END)
           / (SELECT total_gross_revenue FROM totals) AS top_50pct_gross_revenue_share
FROM ranked;

/* 1(c)(ii) TIME TO FIRST PURCHASE: profile's lifetime first_purchase_date. */
WITH t AS (
    SELECT device_id, install_date, first_purchase_date,
           CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) AS days_to_first_purchase,
           CASE WHEN first_purchase_date IS NULL THEN 'never_paid'
                WHEN julianday(first_purchase_date) < julianday(install_date) THEN 'invalid_before_install'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) = 0 THEN '0'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) = 1 THEN '1'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) BETWEEN 2 AND 3 THEN '2-3'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) BETWEEN 4 AND 7 THEN '4-7'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) BETWEEN 8 AND 14 THEN '8-14'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) BETWEEN 15 AND 30 THEN '15-30'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) BETWEEN 31 AND 60 THEN '31-60'
                WHEN CAST(julianday(first_purchase_date) - julianday(install_date) AS INTEGER) BETWEEN 61 AND 90 THEN '61-90'
                ELSE '90+' END AS time_bin
    FROM player_profile
)
SELECT time_bin, COUNT(*) AS players,
       ROUND(COUNT(*) * 1.0 / (SELECT COUNT(*) FROM t), 6) AS share_of_all_players,
       CASE WHEN time_bin NOT IN ('never_paid','invalid_before_install') THEN
            ROUND(COUNT(*) * 1.0 / (SELECT COUNT(*) FROM t WHERE first_purchase_date IS NOT NULL
                                    AND julianday(first_purchase_date) >= julianday(install_date)), 6)
            ELSE NULL END AS share_of_valid_payers
FROM t
GROUP BY time_bin
ORDER BY CASE time_bin WHEN '0' THEN 1 WHEN '1' THEN 2 WHEN '2-3' THEN 3 WHEN '4-7' THEN 4
                       WHEN '8-14' THEN 5 WHEN '15-30' THEN 6 WHEN '31-60' THEN 7
                       WHEN '61-90' THEN 8 WHEN '90+' THEN 9 ELSE 10 END;

/* 1(c)(iii) REPEAT PURCHASE GAP: positive purchases only; each consecutive gap. */
WITH positive_purchases AS (
    SELECT device_id, datetime(event_date || ' ' || printf('%02d:%s', CAST(substr(event_time,1,instr(event_time,':')-1) AS INTEGER), substr(event_time,instr(event_time,':')+1))) AS purchase_ts,
           usd_amount,
           LAG(datetime(event_date || ' ' || printf('%02d:%s', CAST(substr(event_time,1,instr(event_time,':')-1) AS INTEGER), substr(event_time,instr(event_time,':')+1)))) OVER (
               PARTITION BY device_id ORDER BY datetime(event_date || ' ' || printf('%02d:%s', CAST(substr(event_time,1,instr(event_time,':')-1) AS INTEGER), substr(event_time,instr(event_time,':')+1))), rowid
           ) AS previous_purchase_ts
    FROM purchase
    WHERE usd_amount > 0
), gaps AS (
    SELECT device_id,
           (julianday(purchase_ts) - julianday(previous_purchase_ts)) AS gap_days
    FROM positive_purchases
    WHERE previous_purchase_ts IS NOT NULL
), ranked_gaps AS (
    SELECT device_id, gap_days,
           ROW_NUMBER() OVER (ORDER BY gap_days) AS rn,
           COUNT(*) OVER () AS n
    FROM gaps
), positions AS (
    SELECT 1.0 + (n - 1) * 0.25 AS p25_pos,
           1.0 + (n - 1) * 0.50 AS median_pos,
           1.0 + (n - 1) * 0.75 AS p75_pos
    FROM ranked_gaps LIMIT 1
)
SELECT COUNT(*) AS consecutive_gaps,
       COUNT(DISTINCT device_id) AS repeat_buyers,
       AVG(gap_days) AS mean_gap_days,
       MAX(CASE WHEN rn = CAST(p25_pos AS INTEGER) THEN gap_days END)
         * (1 - (p25_pos - CAST(p25_pos AS INTEGER)))
       + MAX(CASE WHEN rn = CAST(p25_pos AS INTEGER) + 1 THEN gap_days END)
         * (p25_pos - CAST(p25_pos AS INTEGER)) AS p25_gap_days,
       MAX(CASE WHEN rn = CAST(median_pos AS INTEGER) THEN gap_days END)
         * (1 - (median_pos - CAST(median_pos AS INTEGER)))
       + MAX(CASE WHEN rn = CAST(median_pos AS INTEGER) + 1 THEN gap_days END)
         * (median_pos - CAST(median_pos AS INTEGER)) AS median_gap_days,
       MAX(CASE WHEN rn = CAST(p75_pos AS INTEGER) THEN gap_days END)
         * (1 - (p75_pos - CAST(p75_pos AS INTEGER)))
       + MAX(CASE WHEN rn = CAST(p75_pos AS INTEGER) + 1 THEN gap_days END)
         * (p75_pos - CAST(p75_pos AS INTEGER)) AS p75_gap_days,
       MIN(gap_days) AS min_gap_days,
       MAX(gap_days) AS max_gap_days
FROM ranked_gaps CROSS JOIN positions;

/* ------------------------------------------------------------------
   1(d)(i) REWARDED-AD CAP HIT RATE BY CAP VALUE
   An ad-watching player-day has >=1 completed rewarded ad. A day is a cap
   hit if any completed event has ad_daily_count >= its contemporaneous cap.
   The day is classified by the cap on the completed event with peak count.
   ------------------------------------------------------------------ */
WITH completed AS (
    SELECT device_id, date(event_ts) AS ad_date, event_ts,
           ad_daily_count, ad_daily_cap,
           CASE WHEN ad_daily_count >= ad_daily_cap THEN 1 ELSE 0 END AS event_hit
    FROM ad_view
    WHERE status = 'completed'
      AND date(event_ts) BETWEEN '2026-01-01' AND '2026-04-30'
), per_day AS (
    SELECT device_id, ad_date,
           MAX(event_hit) AS hit_cap,
           MAX(ad_daily_count) AS peak_count,
           COUNT(DISTINCT ad_daily_cap) AS cap_values
    FROM completed
    GROUP BY device_id, ad_date
), peak_cap AS (
    SELECT device_id, ad_date, ad_daily_cap AS cap_at_peak,
           ROW_NUMBER() OVER (PARTITION BY device_id, ad_date
                              ORDER BY ad_daily_count DESC, event_ts ASC) AS rn
    FROM completed
)
SELECT pc.cap_at_peak AS ad_daily_cap,
       COUNT(*) AS completed_ad_player_days,
       SUM(pd.hit_cap) AS cap_hit_player_days,
       ROUND(1.0 * SUM(pd.hit_cap) / COUNT(*), 6) AS share_hit_cap,
       SUM(CASE WHEN pd.cap_values > 1 THEN 1 ELSE 0 END) AS days_with_inconsistent_cap
FROM per_day pd
JOIN peak_cap pc ON pc.device_id = pd.device_id AND pc.ad_date = pd.ad_date AND pc.rn = 1
GROUP BY pc.cap_at_peak
ORDER BY pc.cap_at_peak;

/* 1(d)(ii) DAILY AD INTERACTIONS / COMPLETIONS; NULL flags a telemetry gap. */
WITH RECURSIVE calendar(day) AS (
    SELECT '2026-01-01'
    UNION ALL SELECT date(day, '+1 day') FROM calendar WHERE day < '2026-04-30'
), ad_daily AS (
    SELECT date(event_ts) AS day, COUNT(*) AS all_interactions,
           SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
           SUM(CASE WHEN status = 'started' THEN 1 ELSE 0 END) AS started,
           SUM(CASE WHEN status = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
    FROM ad_view
    WHERE date(event_ts) BETWEEN '2026-01-01' AND '2026-04-30'
    GROUP BY date(event_ts)
), dau AS (
    SELECT date(substr(CAST(activity_date AS TEXT),1,4) || '-' ||
                substr(CAST(activity_date AS TEXT),5,2) || '-' ||
                substr(CAST(activity_date AS TEXT),7,2)) AS day,
           COUNT(DISTINCT device_id) AS dau
    FROM player_day GROUP BY 1
)
SELECT c.day,
       CASE WHEN a.day IS NULL THEN NULL ELSE a.all_interactions END AS all_interactions,
       CASE WHEN a.day IS NULL THEN NULL ELSE a.completed END AS completed_views,
       CASE WHEN a.day IS NULL THEN NULL ELSE a.started END AS started,
       CASE WHEN a.day IS NULL THEN NULL ELSE a.abandoned END AS abandoned,
       d.dau,
       CASE WHEN a.day IS NULL THEN NULL ELSE 1.0 * a.all_interactions / NULLIF(d.dau,0) END AS interactions_per_dau
FROM calendar c LEFT JOIN ad_daily a ON a.day = c.day LEFT JOIN dau d ON d.day = c.day
ORDER BY c.day;

/* ------------------------------------------------------------------
   2(a) ARPDAU FIRST 30 VS LAST 30 DAYS BY COUNTRY TIER
   ARPDAU = positive gross purchase revenue / sum of daily active players (player-days).
   ------------------------------------------------------------------ */
WITH activity AS (
    SELECT date(substr(CAST(d.activity_date AS TEXT),1,4) || '-' ||
                substr(CAST(d.activity_date AS TEXT),5,2) || '-' ||
                substr(CAST(d.activity_date AS TEXT),7,2)) AS day,
           p.country_tier, COUNT(DISTINCT d.device_id) AS dau
    FROM player_day d JOIN player_profile p ON p.device_id=d.device_id
    GROUP BY 1,2
), revenue AS (
    SELECT date(pu.event_date) AS day, p.country_tier, SUM(CASE WHEN pu.usd_amount > 0 THEN pu.usd_amount ELSE 0 END) AS revenue
    FROM purchase pu JOIN player_profile p ON p.device_id=pu.device_id
    GROUP BY 1,2
), combined AS (
    SELECT a.day, a.country_tier, a.dau, COALESCE(r.revenue,0) AS revenue,
           CASE WHEN a.day BETWEEN '2026-01-01' AND '2026-01-30' THEN 'first30'
                WHEN a.day BETWEEN '2026-04-01' AND '2026-04-30' THEN 'last30' END AS period
    FROM activity a LEFT JOIN revenue r ON r.day=a.day AND r.country_tier=a.country_tier
    WHERE a.day BETWEEN '2026-01-01' AND '2026-04-30'
)
SELECT period, country_tier, SUM(dau) AS active_player_days, SUM(revenue) AS revenue,
       SUM(revenue) / NULLIF(SUM(dau),0) AS arpdau,
       SUM(dau) * 1.0 / SUM(SUM(dau)) OVER (PARTITION BY period) AS dau_mix
FROM combined
WHERE period IS NOT NULL
GROUP BY period, country_tier
ORDER BY period, country_tier;

/* ------------------------------------------------------------------
   3) ACQUISITION CHANNEL: FIRST 30 DAYS AFTER INSTALL
   Cohorts installed Jan 1-Mar 31 have a complete 30-day window by Apr 30.
   Gross revenue per install includes zero-spend players; negative adjustments are not included in gross revenue.
   ------------------------------------------------------------------ */
WITH eligible AS (
    SELECT device_id, date(install_date) AS install_date,
           acquisition_channel, country_tier, platform,
           date(install_date, '+30 days') AS end_exclusive
    FROM player_profile
    WHERE date(install_date) BETWEEN '2026-01-01' AND '2026-03-31'
), activity_30 AS (
    SELECT e.device_id, COUNT(DISTINCT d.activity_date) AS active_days_30,
           SUM(d.session_count) AS sessions_30,
           SUM(d.playtime_minutes) AS playtime_30
    FROM eligible e LEFT JOIN player_day d
      ON d.device_id=e.device_id
     AND date(substr(CAST(d.activity_date AS TEXT),1,4) || '-' ||
              substr(CAST(d.activity_date AS TEXT),5,2) || '-' ||
              substr(CAST(d.activity_date AS TEXT),7,2)) >= e.install_date
     AND date(substr(CAST(d.activity_date AS TEXT),1,4) || '-' ||
              substr(CAST(d.activity_date AS TEXT),5,2) || '-' ||
              substr(CAST(d.activity_date AS TEXT),7,2)) < e.end_exclusive
    GROUP BY e.device_id
), revenue_30 AS (
    SELECT e.device_id,
           SUM(CASE WHEN pu.usd_amount > 0 THEN pu.usd_amount ELSE 0 END) AS gross_revenue_30,
           SUM(pu.usd_amount) AS net_revenue_30,
           SUM(CASE WHEN pu.usd_amount > 0 THEN 1 ELSE 0 END) AS positive_purchases_30
    FROM eligible e LEFT JOIN purchase pu
      ON pu.device_id=e.device_id
     AND datetime(pu.event_date || ' ' || printf('%02d:%s', CAST(substr(pu.event_time,1,instr(pu.event_time,':')-1) AS INTEGER), substr(pu.event_time,instr(pu.event_time,':')+1))) >= datetime(e.install_date)
     AND datetime(pu.event_date || ' ' || printf('%02d:%s', CAST(substr(pu.event_time,1,instr(pu.event_time,':')-1) AS INTEGER), substr(pu.event_time,instr(pu.event_time,':')+1))) < datetime(e.end_exclusive)
    GROUP BY e.device_id
)
SELECT e.acquisition_channel, e.country_tier, e.platform,
       COUNT(*) AS installs,
       AVG(COALESCE(a.active_days_30,0)) AS avg_active_days_30,
       AVG(COALESCE(a.playtime_30,0)) AS avg_playtime_minutes_30,
       AVG(COALESCE(r.gross_revenue_30,0)) AS gross_revenue_per_install_30,
       AVG(CASE WHEN COALESCE(r.positive_purchases_30,0)>0 THEN 1.0 ELSE 0.0 END) AS payer_rate_30
FROM eligible e
LEFT JOIN activity_30 a ON a.device_id=e.device_id
LEFT JOIN revenue_30 r ON r.device_id=e.device_id
GROUP BY e.acquisition_channel, e.country_tier, e.platform
ORDER BY e.acquisition_channel, e.country_tier, e.platform;

/* DATA QUALITY CHECKS: run and preserve outputs in the appendix. */
SELECT COUNT(*) AS duplicate_player_day_rows
FROM (SELECT device_id, activity_date, COUNT(*) n FROM player_day GROUP BY 1,2 HAVING n>1);
SELECT COUNT(*) AS negative_purchase_rows, SUM(usd_amount) AS negative_purchase_total
FROM purchase WHERE usd_amount < 0;
SELECT COUNT(*) AS duplicate_purchase_id_groups
FROM (SELECT purchase_id FROM purchase GROUP BY purchase_id HAVING COUNT(*)>1);
SELECT COUNT(*) AS first_purchase_before_install
FROM player_profile
WHERE first_purchase_date IS NOT NULL AND date(first_purchase_date)<date(install_date);
SELECT date(event_ts) AS event_day, COUNT(*) AS ad_rows
FROM ad_view
GROUP BY date(event_ts)
HAVING date(event_ts) NOT BETWEEN '2026-01-01' AND '2026-04-30'
ORDER BY event_day;
