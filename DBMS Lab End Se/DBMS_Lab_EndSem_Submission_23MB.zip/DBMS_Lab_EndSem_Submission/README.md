# DBMS Lab End-Sem — Player Telemetry Analytics

**Institution:** National Institute of Technology Warangal (NIT Warangal)  
**Student:** Thirumal  |  **Roll number:** 24MAB0A25  
**Course:** Database Management Systems (DBMS)  
**Course instructor:** Dr. Vikas Srivastava

**Submission date:** 25 November 2026  
**Analysis window:** 1 January–30 April 2026  
**Selected deep dive:** Deliverable 2(a), “ARPDAU is falling. Fix it.”

## Submission contents

- `DBMS_Lab_EndSem_Readout.pptx` — 17-slide deck with NIT Warangal, student, roll number, course and instructor details on the cover. Slides 1–8 are the Product Director readout (within the 8-slide limit); slides 9–17 are the appendix for deliverables 1–4.
- `sql/dbms_queries.sql` — SQLite queries for the requested SQL analyses, the ARPDAU deep dive, channel cohort outputs, and data-quality checks.
- `data/` — all five data tables as CSV files. The three supplied XLSX files were converted to CSV. `player_profile.pdf` and `purchase.pdf` were reconstructed into row-aligned CSVs by pairing their split-column PDF pages.
- `code/run_analysis.py` — creates the SQL-style descriptive outputs, retention cohorts, channel cohort dataset and churn training panel.
- `code/train_churn_model.py` — trains and evaluates the logistic-regression churn model.
- `code/build_charts.py` and `code/build_deck.py` — rebuild the charts and PowerPoint.
- `code/load_sqlite.py` — loads the five CSVs into a local SQLite database for running `sql/dbms_queries.sql`.
- `code/rebuild_pdf_exports.py` — optional, reproducible parser for rebuilding the profile and purchase CSVs from the supplied split-column PDFs (requires Poppler `pdftotext`).
- `results/` — machine-readable output tables, model coefficients, calibration and summary JSON.
- `charts/` — PNG charts used in the deck.

## Rebuild instructions

Python 3.10+ is recommended. Install:

```bash
pip install pandas numpy scipy scikit-learn statsmodels matplotlib python-pptx
```

From this folder, run:

```bash
python code/run_all.py
```

That rebuilds the descriptive outputs, churn model, charts and PowerPoint. The runner limits BLAS thread counts to avoid severe CPU oversubscription on high-core-count systems. To create a SQLite database for the SQL file:

```bash
python code/load_sqlite.py
```

Then open `dbms_telemetry.sqlite` in DB Browser for SQLite, SQLiteStudio, or another SQLite client and execute `sql/dbms_queries.sql`. The SQL uses SQLite 3.25+ window functions. `load_sqlite.py` creates the database locally; the generated database is not required in the ZIP because it can be rebuilt from `data/`.

## Important definitions and decisions

1. **DAU:** distinct `device_id` with a `player_day` row on that date. ARPDAU denominator is the sum of daily active players (player-days), not distinct monthly players.
2. **Gross revenue:** sum of positive `purchase.usd_amount` values. Negative purchase rows are shown separately as adjustments and retained when calculating signed net revenue. The brief asks for gross revenue; therefore ARPDAU and channel gross revenue use positive purchase amounts.
3. **Daily payer share:** distinct devices with at least one positive purchase on that date AND a same-day player_day row, divided by DAU. Purchases without same-day activity remain in gross revenue but are not in the active-payer numerator.
4. **Retention:** exact activity on install date + 1, +7, +14 or +30 days; install day is day 0. Cohorts are Monday-start install weeks. A milestone is included in the denominator only if it falls on or before 30 April. Later cells are NULL/right-censored, not zero.
5. **Revenue concentration:** payer population is players with at least one positive purchase. Payers are ranked by their positive gross purchase revenue; the denominator is total positive gross purchase revenue. Net revenue sensitivity is also included in `results/revenue_concentration.csv`.
6. **Time to first purchase:** uses the profile's `first_purchase_date` field, which matches the earliest positive purchase date for valid payers. The 110 dates before install are excluded from the time distribution and separately flagged.
7. **Repeat purchase gap:** consecutive positive purchase events per device, using event timestamps. The duplicate `purchase_id` values are not deduplicated because colliding IDs have different timestamps.
8. **Ad cap:** an ad-watching player-day has at least one completed rewarded-ad event. A cap hit occurs if any completed event's `ad_daily_count` reaches that event's `ad_daily_cap`. The player-day is grouped by the cap on the event with the peak count.
9. **Channel comparison:** first 30 days after install for 1 January–31 March installs only, ensuring complete 30-day follow-up by 30 April. Revenue per install includes zero-spend players. The adjusted OLS controls for country tier, platform and install week and uses HC3 robust standard errors. This is an observational comparison, not a causal estimate.
10. **Churn:** among players installed at least 14 days before a snapshot and active in the previous 7 days, churn means no `player_day` activity in the next 14 days. Training uses snapshots through 19 March; the temporal test is the 16 April snapshot, with a complete outcome horizon through 29 April.

## Scope choices

- Deliverable 2(a) was selected. The alternative sale-frequency analysis in 2(b) was not selected.
- Optional deliverable 4(b), 90-day revenue prediction, was left out so the required churn analysis could be completed and evaluated carefully.
- No marketing spend/CPI, ad-network revenue, offer cost/uplift, support tickets or survey responses are present in the supplied data. Recommendations that require those inputs are stated conditionally.
